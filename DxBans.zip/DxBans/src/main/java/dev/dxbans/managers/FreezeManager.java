package dev.dxbans.managers;

import dev.dxbans.DxBans;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class FreezeManager {

    private final DxBans plugin;
    private final Set<UUID> frozenPlayers = new HashSet<>();

    public FreezeManager(DxBans plugin) {
        this.plugin = plugin;
    }

    public boolean freeze(UUID uuid) {
        if (frozenPlayers.contains(uuid)) return false;
        frozenPlayers.add(uuid);
        return true;
    }

    public boolean unfreeze(UUID uuid) {
        return frozenPlayers.remove(uuid);
    }

    public boolean isFrozen(UUID uuid) {
        return frozenPlayers.contains(uuid);
    }

    public void removeOnQuit(UUID uuid) {
        frozenPlayers.remove(uuid);
    }

    public Set<UUID> getFrozenPlayers() {
        return frozenPlayers;
    }
}
