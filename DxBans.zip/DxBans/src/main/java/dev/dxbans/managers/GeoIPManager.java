package dev.dxbans.managers;

import dev.dxbans.DxBans;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class GeoIPManager {

    private final DxBans plugin;
    // Simple cache: IP → Country
    private final Map<String, String> countryCache = new HashMap<>();

    public GeoIPManager(DxBans plugin) {
        this.plugin = plugin;
    }

    /**
     * Get country name for an IP address.
     * Uses free ip-api.com service (no API key needed for basic use).
     * Falls back to "Unknown" on error.
     */
    public String getCountry(String ip) {
        if (ip == null || ip.startsWith("127.") || ip.startsWith("192.168.") || ip.equals("0:0:0:0:0:0:0:1")) {
            return "Localhost";
        }
        if (countryCache.containsKey(ip)) {
            return countryCache.get(ip);
        }
        try {
            URL url = new URL("http://ip-api.com/json/" + ip + "?fields=country,regionName,isp,status");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);

            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();

                String json = sb.toString();
                if (json.contains("\"status\":\"success\"")) {
                    String country = extractJson(json, "country");
                    countryCache.put(ip, country);
                    return country;
                }
            }
        } catch (Exception ignored) {}
        return "Unknown";
    }

    public String getRegion(String ip) {
        if (ip == null) return "Unknown";
        try {
            URL url = new URL("http://ip-api.com/json/" + ip + "?fields=regionName");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String json = reader.readLine();
                reader.close();
                return extractJson(json, "regionName");
            }
        } catch (Exception ignored) {}
        return "Unknown";
    }

    public String getIsp(String ip) {
        if (ip == null) return "Unknown";
        try {
            URL url = new URL("http://ip-api.com/json/" + ip + "?fields=isp");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String json = reader.readLine();
                reader.close();
                return extractJson(json, "isp");
            }
        } catch (Exception ignored) {}
        return "Unknown";
    }

    public boolean isCountryBlocked(String ip) {
        if (!plugin.getConfig().getBoolean("geoip.country-block.enabled", false)) return false;
        String country = getCountry(ip);
        java.util.List<String> blocked = plugin.getConfig().getStringList("geoip.country-block.blocked-countries");
        return blocked.stream().anyMatch(c -> c.equalsIgnoreCase(country));
    }

    private String extractJson(String json, String key) {
        String search = "\"" + key + "\":\"";
        int start = json.indexOf(search);
        if (start == -1) return "Unknown";
        start += search.length();
        int end = json.indexOf("\"", start);
        if (end == -1) return "Unknown";
        return json.substring(start, end);
    }
}
