package dev.dxbans.managers;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.models.Punishment.Type;

import java.sql.*;
import java.util.*;

public class WarnManager {

    private final DxBans plugin;

    public WarnManager(DxBans plugin) {
        this.plugin = plugin;
    }

    public Punishment warn(UUID uuid, String name, String reason, String operator, UUID operatorUUID, String server) {
        return warnInternal(uuid, name, reason, operator, operatorUUID, server, -1, Type.WARN);
    }

    public Punishment tempwarn(UUID uuid, String name, String reason, String operator, UUID operatorUUID, String server, long duration) {
        long until = System.currentTimeMillis() + duration;
        return warnInternal(uuid, name, reason, operator, operatorUUID, server, until, Type.TEMPWARN);
    }

    private Punishment warnInternal(UUID uuid, String name, String reason, String operator,
                                    UUID operatorUUID, String server, long until, Type type) {
        Punishment p = new Punishment(uuid, name, type, reason, operator, operatorUUID,
                System.currentTimeMillis(), until, server, false);
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "INSERT INTO " + plugin.getDatabaseManager().t("warnings") +
                    " (uuid, name, reason, operator, operator_uuid, date, until, server, active, type) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)";
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, uuid.toString());
            ps.setString(2, name);
            ps.setString(3, reason);
            ps.setString(4, operator);
            ps.setString(5, operatorUUID != null ? operatorUUID.toString() : null);
            ps.setLong(6, p.getDate());
            ps.setLong(7, until);
            ps.setString(8, server);
            ps.setString(9, type.name().toLowerCase());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) p.setId(keys.getLong(1));
        } catch (SQLException e) {
            plugin.getLogger().severe("Error saving warning: " + e.getMessage());
        }
        plugin.getHistoryManager().logPunishment(p);

        // Check auto-punish thresholds
        checkAutoPunish(uuid, name, server, operator, operatorUUID);

        return p;
    }

    public boolean removeWarn(long id, String removedBy) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE " + plugin.getDatabaseManager().t("warnings") +
                    " SET active = 0 WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { return false; }
    }

    public boolean removeLatestWarn(UUID uuid, String removedBy) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE " + plugin.getDatabaseManager().t("warnings") +
                    " SET active = 0 WHERE uuid = ? AND active = 1 ORDER BY date DESC LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { return false; }
    }

    public int getActiveWarnCount(UUID uuid) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT COUNT(*) FROM " + plugin.getDatabaseManager().t("warnings") +
                    " WHERE uuid = ? AND active = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { /* ignore */ }
        return 0;
    }

    public List<Punishment> getWarnings(UUID uuid, boolean activeOnly) {
        List<Punishment> list = new ArrayList<>();
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT * FROM " + plugin.getDatabaseManager().t("warnings") +
                    " WHERE uuid = ?" + (activeOnly ? " AND active = 1" : "") + " ORDER BY date DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Punishment p = new Punishment();
                p.setId(rs.getLong("id"));
                p.setPlayerUUID(uuid);
                p.setPlayerName(rs.getString("name"));
                p.setReason(rs.getString("reason"));
                p.setOperator(rs.getString("operator"));
                p.setDate(rs.getLong("date"));
                p.setUntil(rs.getLong("until"));
                p.setActive(rs.getInt("active") == 1);
                p.setServer(rs.getString("server"));
                try { p.setType(Type.valueOf(rs.getString("type").toUpperCase())); }
                catch (Exception ignored) { p.setType(Type.WARN); }
                list.add(p);
            }
        } catch (SQLException e) { /* ignore */ }
        return list;
    }

    public int getTotalWarns() {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) FROM " + plugin.getDatabaseManager().t("warnings"));
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { /* ignore */ }
        return 0;
    }

    private void checkAutoPunish(UUID uuid, String name, String server, String operator, UUID operatorUUID) {
        if (!plugin.getConfig().getBoolean("punishments.warn.auto-punish.enabled", true)) return;

        int warnCount = getActiveWarnCount(uuid);
        var thresholds = plugin.getConfig().getConfigurationSection("punishments.warn.auto-punish.thresholds");
        if (thresholds == null) return;

        for (String key : thresholds.getKeys(false)) {
            try {
                int threshold = Integer.parseInt(key);
                if (warnCount == threshold) {
                    String type   = thresholds.getString(key + ".type", "tempban");
                    String reason = thresholds.getString(key + ".reason", "Auto-punishment from warnings");
                    String dur    = thresholds.getString(key + ".duration", "1d");

                    org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
                        switch (type.toLowerCase()) {
                            case "tempban" -> {
                                long duration = dev.dxbans.utils.DurationUtil.parse(dur);
                                plugin.getBanManager().tempban(uuid, name, reason, "[DxBans Auto]", null, server, duration, false);
                            }
                            case "ban" -> plugin.getBanManager().ban(uuid, name, reason, "[DxBans Auto]", null, server, false);
                            case "tempmute" -> {
                                long duration = dev.dxbans.utils.DurationUtil.parse(dur);
                                plugin.getMuteManager().tempmute(uuid, name, reason, "[DxBans Auto]", null, server, duration, false);
                            }
                            case "mute" -> plugin.getMuteManager().mute(uuid, name, reason, "[DxBans Auto]", null, server, false);
                        }
                    });
                    break;
                }
            } catch (NumberFormatException ignored) {}
        }
    }
}
