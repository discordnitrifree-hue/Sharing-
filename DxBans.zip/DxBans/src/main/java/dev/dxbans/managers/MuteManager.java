package dev.dxbans.managers;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.models.Punishment.Type;

import java.sql.*;
import java.util.*;

public class MuteManager {

    private final DxBans plugin;
    private final Map<UUID, Punishment> muteCache = new HashMap<>();

    public MuteManager(DxBans plugin) {
        this.plugin = plugin;
        loadActiveMutes();
    }

    public Punishment mute(UUID uuid, String name, String reason, String operator, UUID operatorUUID, String server, boolean silent) {
        return muteInternal(uuid, name, reason, operator, operatorUUID, server, -1, Type.MUTE, silent);
    }

    public Punishment tempmute(UUID uuid, String name, String reason, String operator, UUID operatorUUID, String server, long duration, boolean silent) {
        long until = System.currentTimeMillis() + duration;
        return muteInternal(uuid, name, reason, operator, operatorUUID, server, until, Type.TEMPMUTE, silent);
    }

    private Punishment muteInternal(UUID uuid, String name, String reason, String operator,
                                    UUID operatorUUID, String server, long until, Type type, boolean silent) {
        Punishment p = new Punishment(uuid, name, type, reason, operator, operatorUUID,
                System.currentTimeMillis(), until, server, silent);
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "INSERT INTO " + plugin.getDatabaseManager().t("mutes") +
                    " (uuid, name, reason, operator, operator_uuid, date, until, server, active, silent, type) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, uuid.toString());
            ps.setString(2, name);
            ps.setString(3, reason);
            ps.setString(4, operator);
            ps.setString(5, operatorUUID != null ? operatorUUID.toString() : null);
            ps.setLong(6, p.getDate());
            ps.setLong(7, until);
            ps.setString(8, server);
            ps.setInt(9, silent ? 1 : 0);
            ps.setString(10, type.name().toLowerCase());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) p.setId(keys.getLong(1));
        } catch (SQLException e) {
            plugin.getLogger().severe("Error saving mute: " + e.getMessage());
        }
        muteCache.put(uuid, p);
        plugin.getHistoryManager().logPunishment(p);
        return p;
    }

    public boolean unmute(UUID uuid, String removedBy) {
        if (!isMuted(uuid)) return false;
        muteCache.remove(uuid);
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE " + plugin.getDatabaseManager().t("mutes") +
                    " SET active = 0, removed_by = ?, removed_date = ? WHERE uuid = ? AND active = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, removedBy);
            ps.setLong(2, System.currentTimeMillis());
            ps.setString(3, uuid.toString());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Error unmuting: " + e.getMessage());
            return false;
        }
    }

    public boolean isMuted(UUID uuid) {
        Punishment p = muteCache.get(uuid);
        if (p != null && p.isExpired()) {
            muteCache.remove(uuid);
            unmute(uuid, "System");
            return false;
        }
        return p != null && p.isActive();
    }

    public Punishment getActiveMute(UUID uuid) {
        Punishment p = muteCache.get(uuid);
        if (p == null || !p.isActive()) return null;
        return p;
    }

    public List<Punishment> getActiveMutes(int page, int perPage) {
        List<Punishment> list = new ArrayList<>();
        int offset = (page - 1) * perPage;
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT * FROM " + plugin.getDatabaseManager().t("mutes") +
                    " WHERE active = 1 ORDER BY date DESC LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, perPage);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapMute(rs));
        } catch (SQLException e) { /* ignore */ }
        return list;
    }

    public int getTotalActiveMutes() {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) FROM " + plugin.getDatabaseManager().t("mutes") + " WHERE active = 1");
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { /* ignore */ }
        return 0;
    }

    public int getTotalMutes() {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) FROM " + plugin.getDatabaseManager().t("mutes"));
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { /* ignore */ }
        return 0;
    }

    private void loadActiveMutes() {
        muteCache.clear();
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT * FROM " + plugin.getDatabaseManager().t("mutes") + " WHERE active = 1");
            while (rs.next()) {
                Punishment p = mapMute(rs);
                if (!p.isExpired() && p.getPlayerUUID() != null) {
                    muteCache.put(p.getPlayerUUID(), p);
                }
            }
            plugin.getLogger().info("Loaded " + muteCache.size() + " active mutes.");
        } catch (SQLException e) {
            plugin.getLogger().severe("Error loading active mutes: " + e.getMessage());
        }
    }

    private Punishment mapMute(ResultSet rs) throws SQLException {
        Punishment p = new Punishment();
        p.setId(rs.getLong("id"));
        try { p.setPlayerUUID(UUID.fromString(rs.getString("uuid"))); } catch (Exception ignored) {}
        p.setPlayerName(rs.getString("name"));
        p.setReason(rs.getString("reason"));
        p.setOperator(rs.getString("operator"));
        p.setDate(rs.getLong("date"));
        p.setUntil(rs.getLong("until"));
        p.setServer(rs.getString("server"));
        p.setActive(rs.getInt("active") == 1);
        p.setSilent(rs.getInt("silent") == 1);
        try { p.setType(Type.valueOf(rs.getString("type").toUpperCase())); }
        catch (Exception ignored) { p.setType(Type.MUTE); }
        return p;
    }

    public void expireActiveMutes() {
        new ArrayList<>(muteCache.entrySet()).forEach(entry -> {
            if (entry.getValue().isExpired()) {
                muteCache.remove(entry.getKey());
                unmute(entry.getKey(), "System");
            }
        });
    }
}
