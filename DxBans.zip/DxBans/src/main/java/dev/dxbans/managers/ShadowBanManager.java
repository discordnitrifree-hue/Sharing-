package dev.dxbans.managers;

import dev.dxbans.DxBans;

import java.sql.*;
import java.util.*;

public class ShadowBanManager {

    private final DxBans plugin;
    private final Set<UUID> shadowBanned = new HashSet<>();

    public ShadowBanManager(DxBans plugin) {
        this.plugin = plugin;
        loadShadowBanned();
    }

    public boolean shadowBan(UUID uuid, String name, String reason, String operator) {
        if (isShadowBanned(uuid)) return false;
        shadowBanned.add(uuid);
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            // Store in players table
            String sql = "UPDATE " + plugin.getDatabaseManager().t("players") +
                    " SET shadowbanned = 1 WHERE uuid = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error saving shadowban: " + e.getMessage());
        }
        return true;
    }

    public boolean unShadowBan(UUID uuid) {
        if (!isShadowBanned(uuid)) return false;
        shadowBanned.remove(uuid);
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE " + plugin.getDatabaseManager().t("players") +
                    " SET shadowbanned = 0 WHERE uuid = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) { /* ignore */ }
        return true;
    }

    public boolean isShadowBanned(UUID uuid) {
        return shadowBanned.contains(uuid);
    }

    private void loadShadowBanned() {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT uuid FROM " + plugin.getDatabaseManager().t("players") + " WHERE shadowbanned = 1");
            while (rs.next()) {
                try { shadowBanned.add(UUID.fromString(rs.getString("uuid"))); } catch (Exception ignored) {}
            }
        } catch (SQLException e) { /* ignore */ }
    }
}
