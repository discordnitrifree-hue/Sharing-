package dev.dxbans.managers;

import dev.dxbans.DxBans;

import java.sql.*;
import java.util.*;

public class AltManager {

    private final DxBans plugin;

    public AltManager(DxBans plugin) {
        this.plugin = plugin;
    }

    public void recordLogin(UUID uuid, String name, String ip) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            // Upsert into players table
            String upsert = plugin.getDatabaseManager().isSqlite() ?
                    "INSERT OR REPLACE INTO " + plugin.getDatabaseManager().t("players") +
                    " (uuid, name, ip, last_seen, first_seen) VALUES (?, ?, ?, ?, " +
                    "COALESCE((SELECT first_seen FROM " + plugin.getDatabaseManager().t("players") + " WHERE uuid = ?), ?))" :
                    "INSERT INTO " + plugin.getDatabaseManager().t("players") +
                    " (uuid, name, ip, last_seen, first_seen) VALUES (?, ?, ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE name = VALUES(name), ip = VALUES(ip), last_seen = VALUES(last_seen)";

            long now = System.currentTimeMillis();
            PreparedStatement ps = conn.prepareStatement(upsert);
            ps.setString(1, uuid.toString());
            ps.setString(2, name);
            ps.setString(3, ip);
            ps.setLong(4, now);
            if (plugin.getDatabaseManager().isSqlite()) {
                ps.setString(5, uuid.toString());
                ps.setLong(6, now);
            } else {
                ps.setLong(5, now);
            }
            ps.executeUpdate();

            // Record in IP history
            String ipHistory = "INSERT INTO " + plugin.getDatabaseManager().t("ip_history") +
                    " (uuid, name, ip, date) VALUES (?, ?, ?, ?)";
            PreparedStatement ps2 = conn.prepareStatement(ipHistory);
            ps2.setString(1, uuid.toString());
            ps2.setString(2, name);
            ps2.setString(3, ip);
            ps2.setLong(4, now);
            ps2.executeUpdate();

        } catch (SQLException e) {
            plugin.getLogger().warning("Error recording login: " + e.getMessage());
        }
    }

    public List<String> getAlts(String ip) {
        List<String> alts = new ArrayList<>();
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT DISTINCT name FROM " + plugin.getDatabaseManager().t("ip_history") +
                    " WHERE ip = ? ORDER BY date DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, ip);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) alts.add(rs.getString("name"));
        } catch (SQLException e) { /* ignore */ }
        return alts;
    }

    public List<String> getAltsByUUID(UUID uuid) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            // First get all IPs for this player
            String ipSql = "SELECT DISTINCT ip FROM " + plugin.getDatabaseManager().t("ip_history") + " WHERE uuid = ?";
            PreparedStatement ps = conn.prepareStatement(ipSql);
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();

            Set<String> ips = new HashSet<>();
            while (rs.next()) ips.add(rs.getString("ip"));

            // Then get all players who share those IPs
            Set<String> alts = new LinkedHashSet<>();
            for (String ip : ips) {
                alts.addAll(getAlts(ip));
            }
            return new ArrayList<>(alts);
        } catch (SQLException e) { /* ignore */ }
        return new ArrayList<>();
    }

    public String getLastIp(UUID uuid) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT ip FROM " + plugin.getDatabaseManager().t("players") + " WHERE uuid = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString("ip");
        } catch (SQLException e) { /* ignore */ }
        return null;
    }

    public UUID getUUIDByName(String name) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT uuid FROM " + plugin.getDatabaseManager().t("players") + " WHERE name = ? COLLATE NOCASE LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return UUID.fromString(rs.getString("uuid"));
        } catch (Exception e) { /* ignore */ }
        return null;
    }
}
