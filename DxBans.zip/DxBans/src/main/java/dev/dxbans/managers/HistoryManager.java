package dev.dxbans.managers;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;

import java.sql.*;
import java.util.*;

public class HistoryManager {

    private final DxBans plugin;

    public HistoryManager(DxBans plugin) {
        this.plugin = plugin;
    }

    public void logPunishment(Punishment p) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "INSERT INTO " + plugin.getDatabaseManager().t("history") +
                    " (uuid, name, type, reason, operator, date, duration, server, ref_id) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, p.getPlayerUUID() != null ? p.getPlayerUUID().toString() : "");
            ps.setString(2, p.getPlayerName());
            ps.setString(3, p.getType().name().toLowerCase());
            ps.setString(4, p.getReason());
            ps.setString(5, p.getOperator());
            ps.setLong(6, p.getDate());
            ps.setLong(7, p.getUntil() == -1 ? -1 : p.getUntil() - p.getDate());
            ps.setString(8, p.getServer());
            ps.setLong(9, p.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error logging history: " + e.getMessage());
        }
    }

    public List<Punishment> getHistory(UUID uuid, int page, int perPage) {
        List<Punishment> list = new ArrayList<>();
        int offset = (page - 1) * perPage;
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT * FROM " + plugin.getDatabaseManager().t("history") +
                    " WHERE uuid = ? ORDER BY date DESC LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ps.setInt(2, perPage);
            ps.setInt(3, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Punishment p = new Punishment();
                p.setId(rs.getLong("id"));
                p.setPlayerUUID(uuid);
                p.setPlayerName(rs.getString("name"));
                p.setReason(rs.getString("reason"));
                p.setOperator(rs.getString("operator"));
                p.setDate(rs.getLong("date"));
                p.setServer(rs.getString("server"));
                try { p.setType(Punishment.Type.valueOf(rs.getString("type").toUpperCase())); }
                catch (Exception ignored) {}
                list.add(p);
            }
        } catch (SQLException e) { /* ignore */ }
        return list;
    }

    public int getHistoryCount(UUID uuid) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT COUNT(*) FROM " + plugin.getDatabaseManager().t("history") + " WHERE uuid = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { /* ignore */ }
        return 0;
    }

    public List<Punishment> getStaffHistory(String staffName, int page, int perPage) {
        List<Punishment> list = new ArrayList<>();
        int offset = (page - 1) * perPage;
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT * FROM " + plugin.getDatabaseManager().t("history") +
                    " WHERE operator = ? ORDER BY date DESC LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, staffName);
            ps.setInt(2, perPage);
            ps.setInt(3, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Punishment p = new Punishment();
                p.setId(rs.getLong("id"));
                p.setPlayerName(rs.getString("name"));
                p.setReason(rs.getString("reason"));
                p.setOperator(rs.getString("operator"));
                p.setDate(rs.getLong("date"));
                p.setServer(rs.getString("server"));
                try { p.setType(Punishment.Type.valueOf(rs.getString("type").toUpperCase())); }
                catch (Exception ignored) {}
                list.add(p);
            }
        } catch (SQLException e) { /* ignore */ }
        return list;
    }

    public void clearHistory(UUID uuid) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "DELETE FROM " + plugin.getDatabaseManager().t("history") + " WHERE uuid = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) { /* ignore */ }
    }
}
