package dev.dxbans.managers;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.models.Punishment.Type;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import dev.dxbans.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.*;
import java.util.*;

public class BanManager {

    private final DxBans plugin;
    // Cache of active bans (UUID -> Punishment)
    private final Map<UUID, Punishment> banCache = new HashMap<>();
    // Cache of active IP bans (IP -> Punishment)
    private final Map<String, Punishment> ipBanCache = new HashMap<>();

    public BanManager(DxBans plugin) {
        this.plugin = plugin;
        loadActiveBans();
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // BAN METHODS
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    public Punishment ban(UUID uuid, String name, String reason, String operator, UUID operatorUUID, String server, boolean silent) {
        return banInternal(uuid, name, null, reason, operator, operatorUUID, server, -1, Type.BAN, silent, false);
    }

    public Punishment tempban(UUID uuid, String name, String reason, String operator, UUID operatorUUID, String server, long duration, boolean silent) {
        long until = System.currentTimeMillis() + duration;
        return banInternal(uuid, name, null, reason, operator, operatorUUID, server, until, Type.TEMPBAN, silent, false);
    }

    public Punishment banIp(String ip, String name, UUID uuid, String reason, String operator, UUID operatorUUID, String server, boolean silent) {
        return banInternal(uuid, name, ip, reason, operator, operatorUUID, server, -1, Type.BANIP, silent, true);
    }

    public Punishment tempbanIp(String ip, String name, UUID uuid, String reason, String operator, UUID operatorUUID, String server, long duration, boolean silent) {
        long until = System.currentTimeMillis() + duration;
        return banInternal(uuid, name, ip, reason, operator, operatorUUID, server, until, Type.TEMPBANIP, silent, true);
    }

    private Punishment banInternal(UUID uuid, String name, String ip, String reason, String operator,
                                   UUID operatorUUID, String server, long until, Type type, boolean silent, boolean ipBan) {
        Punishment p = new Punishment(uuid, name, type, reason, operator, operatorUUID,
                System.currentTimeMillis(), until, server, silent);
        p.setIp(ip);
        p.setIpBan(ipBan);

        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "INSERT INTO " + plugin.getDatabaseManager().t("bans") +
                    " (uuid, name, ip, reason, operator, operator_uuid, date, until, server, active, ip_ban, silent, type) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, uuid != null ? uuid.toString() : "");
            ps.setString(2, name);
            ps.setString(3, ip);
            ps.setString(4, reason);
            ps.setString(5, operator);
            ps.setString(6, operatorUUID != null ? operatorUUID.toString() : null);
            ps.setLong(7, p.getDate());
            ps.setLong(8, until);
            ps.setString(9, server);
            ps.setInt(10, ipBan ? 1 : 0);
            ps.setInt(11, silent ? 1 : 0);
            ps.setString(12, type.name().toLowerCase());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) p.setId(keys.getLong(1));
        } catch (SQLException e) {
            plugin.getLogger().severe("Error saving ban: " + e.getMessage());
        }

        // Add to cache
        if (ipBan && ip != null) {
            ipBanCache.put(ip, p);
        } else if (uuid != null) {
            banCache.put(uuid, p);
        }

        // Log to history
        plugin.getHistoryManager().logPunishment(p);

        return p;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // UNBAN METHODS
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    public boolean unban(UUID uuid, String removedBy) {
        if (!isBanned(uuid)) return false;
        banCache.remove(uuid);
        return setInactiveByUUID(uuid, removedBy);
    }

    public boolean unbanIp(String ip, String removedBy) {
        if (!isIpBanned(ip)) return false;
        ipBanCache.remove(ip);
        return setInactiveByIp(ip, removedBy);
    }

    private boolean setInactiveByUUID(UUID uuid, String removedBy) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE " + plugin.getDatabaseManager().t("bans") +
                    " SET active = 0, removed_by = ?, removed_date = ? WHERE uuid = ? AND active = 1 AND ip_ban = 0";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, removedBy);
            ps.setLong(2, System.currentTimeMillis());
            ps.setString(3, uuid.toString());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Error unbanning player: " + e.getMessage());
            return false;
        }
    }

    private boolean setInactiveByIp(String ip, String removedBy) {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "UPDATE " + plugin.getDatabaseManager().t("bans") +
                    " SET active = 0, removed_by = ?, removed_date = ? WHERE ip = ? AND active = 1 AND ip_ban = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, removedBy);
            ps.setLong(2, System.currentTimeMillis());
            ps.setString(3, ip);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Error unbanning IP: " + e.getMessage());
            return false;
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // LOOKUP METHODS
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    public boolean isBanned(UUID uuid) {
        Punishment p = banCache.get(uuid);
        if (p != null && p.isExpired()) {
            banCache.remove(uuid);
            setInactiveByUUID(uuid, "System");
            return false;
        }
        return p != null && p.isActive();
    }

    public boolean isIpBanned(String ip) {
        Punishment p = ipBanCache.get(ip);
        if (p != null && p.isExpired()) {
            ipBanCache.remove(ip);
            setInactiveByIp(ip, "System");
            return false;
        }
        return p != null && p.isActive();
    }

    public Punishment getActiveBan(UUID uuid) {
        Punishment p = banCache.get(uuid);
        if (p == null || !p.isActive()) return null;
        return p;
    }

    public Punishment getActiveIpBan(String ip) {
        return ipBanCache.get(ip);
    }

    public List<Punishment> getActiveBans(int page, int perPage) {
        List<Punishment> list = new ArrayList<>();
        int offset = (page - 1) * perPage;
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            String sql = "SELECT * FROM " + plugin.getDatabaseManager().t("bans") +
                    " WHERE active = 1 ORDER BY date DESC LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, perPage);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapBan(rs));
        } catch (SQLException e) {
            plugin.getLogger().severe("Error fetching ban list: " + e.getMessage());
        }
        return list;
    }

    public int getTotalActiveBans() {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) FROM " + plugin.getDatabaseManager().t("bans") + " WHERE active = 1");
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { /* ignore */ }
        return 0;
    }

    public int getTotalBans() {
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) FROM " + plugin.getDatabaseManager().t("bans"));
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { /* ignore */ }
        return 0;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // CACHE LOADING
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private void loadActiveBans() {
        banCache.clear();
        ipBanCache.clear();
        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT * FROM " + plugin.getDatabaseManager().t("bans") + " WHERE active = 1");
            while (rs.next()) {
                Punishment p = mapBan(rs);
                if (p.isExpired()) {
                    setInactiveByUUID(p.getPlayerUUID(), "System");
                    continue;
                }
                if (p.isIpBan() && p.getIp() != null) {
                    ipBanCache.put(p.getIp(), p);
                } else if (p.getPlayerUUID() != null) {
                    banCache.put(p.getPlayerUUID(), p);
                }
            }
            plugin.getLogger().info("Loaded " + banCache.size() + " active bans, " + ipBanCache.size() + " active IP bans.");
        } catch (SQLException e) {
            plugin.getLogger().severe("Error loading active bans: " + e.getMessage());
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // RESULT SET MAPPER
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    private Punishment mapBan(ResultSet rs) throws SQLException {
        Punishment p = new Punishment();
        p.setId(rs.getLong("id"));
        String uuidStr = rs.getString("uuid");
        if (uuidStr != null && !uuidStr.isEmpty()) {
            try { p.setPlayerUUID(UUID.fromString(uuidStr)); } catch (Exception ignored) {}
        }
        p.setPlayerName(rs.getString("name"));
        p.setIp(rs.getString("ip"));
        p.setReason(rs.getString("reason"));
        p.setOperator(rs.getString("operator"));
        String opUUID = rs.getString("operator_uuid");
        if (opUUID != null) {
            try { p.setOperatorUUID(UUID.fromString(opUUID)); } catch (Exception ignored) {}
        }
        p.setDate(rs.getLong("date"));
        p.setUntil(rs.getLong("until"));
        p.setServer(rs.getString("server"));
        p.setActive(rs.getInt("active") == 1);
        p.setRemovedBy(rs.getString("removed_by"));
        p.setRemovedDate(rs.getLong("removed_date"));
        p.setIpBan(rs.getInt("ip_ban") == 1);
        p.setSilent(rs.getInt("silent") == 1);
        try {
            p.setType(Type.valueOf(rs.getString("type").toUpperCase()));
        } catch (Exception ignored) {
            p.setType(Type.BAN);
        }
        return p;
    }

    // Called from ExpiredPunishmentTask to expire bans
    public void expireActiveBans() {
        new ArrayList<>(banCache.entrySet()).forEach(entry -> {
            if (entry.getValue().isExpired()) {
                banCache.remove(entry.getKey());
                setInactiveByUUID(entry.getKey(), "System");
            }
        });
        new ArrayList<>(ipBanCache.entrySet()).forEach(entry -> {
            if (entry.getValue().isExpired()) {
                ipBanCache.remove(entry.getKey());
                setInactiveByIp(entry.getKey(), "System");
            }
        });
    }
}
