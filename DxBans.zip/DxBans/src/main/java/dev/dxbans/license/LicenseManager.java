package dev.dxbans.license;

import dev.dxbans.DxBans;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.logging.Level;

/**
 * DxBans License Manager
 * ─────────────────────────────────────────────────────────────────
 * The plugin will NOT function without a valid license key.
 * Key is read from config.yml → license.key
 * License key is NEVER exposed in logs, chat, or any output.
 * ─────────────────────────────────────────────────────────────────
 */
public class LicenseManager {

    private final DxBans plugin;
    private String licenseKey;
    private boolean valid = false;
    private long lastValidated = 0;
    private long gracePeriodEnd = 0;

    // Cache file to support offline grace period
    private final File cacheFile;

    private static final String PLACEHOLDER = "ENTER-YOUR-LICENSE-KEY-HERE";
    private static final String VERIFY_URL = "https://dxbans.dev/api/license/verify";

    public LicenseManager(DxBans plugin) {
        this.plugin = plugin;
        this.cacheFile = new File(plugin.getDataFolder(), ".license_cache");
    }

    /**
     * Validates the license key from config.yml.
     * Returns true if valid (online or via offline grace).
     */
    public boolean validate() {
        FileConfiguration config = plugin.getConfig();
        licenseKey = config.getString("license.key", "");

        // ── 1. Check if key is still the placeholder ──
        if (licenseKey == null || licenseKey.isEmpty() || licenseKey.equalsIgnoreCase(PLACEHOLDER)) {
            plugin.getLogger().severe("No license key set in config.yml!");
            plugin.getLogger().severe("Get your key at: https://dxbans.dev/license");
            valid = false;
            return false;
        }

        // ── 2. Validate key format locally (basic sanity check) ──
        if (!isValidFormat(licenseKey)) {
            plugin.getLogger().severe("License key format is invalid.");
            valid = false;
            return false;
        }

        // ── 3. Try online verification ──
        try {
            boolean onlineResult = verifyOnline(licenseKey);
            if (onlineResult) {
                valid = true;
                lastValidated = System.currentTimeMillis();
                saveLicenseCache(licenseKey);
                plugin.setLicenseValid(true);
                return true;
            } else {
                plugin.getLogger().severe("License key rejected by the license server!");
                valid = false;
                // Don't log the key itself
                return false;
            }
        } catch (Exception e) {
            // ── 4. Fallback: Offline grace period ──
            plugin.getLogger().warning("Could not reach license server. Checking offline grace period...");

            int graceMins = plugin.getConfig().getInt("license.offline-grace", 1440);
            long graceMs = graceMins * 60L * 1000L;

            if (loadFromCache(licenseKey) && (System.currentTimeMillis() - lastValidated) < graceMs) {
                plugin.getLogger().warning("Running under offline grace period. (" + graceMins + " minutes)");
                valid = true;
                plugin.setLicenseValid(true);
                return true;
            } else {
                plugin.getLogger().severe("Offline grace period expired! Please reconnect to the internet to validate your license.");
                valid = false;
                return false;
            }
        }
    }

    /**
     * Verifies the license key with the remote API server.
     * The actual key is hashed before being sent for extra security.
     */
    private boolean verifyOnline(String key) throws Exception {
        // Hash key before sending (SHA-256 → Base64) for security
        String hashedKey = hashKey(key);
        String serverId = getServerId();

        URL url = new URL(VERIFY_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("User-Agent", "DxBans/1.0.0");

        // Build JSON body - key is hashed, NEVER sent in plain text
        String body = "{\"hash\":\"" + hashedKey + "\",\"server\":\"" + serverId + "\",\"version\":\"1.0.0\"}";

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }

        int responseCode = conn.getResponseCode();

        if (responseCode == 200) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line);
                }
                String resp = response.toString();
                return resp.contains("\"valid\":true") || resp.contains("\"status\":\"active\"");
            }
        }

        return false;
    }

    /**
     * Basic format check - DxBans keys follow pattern: XXXX-XXXX-XXXX-XXXX
     * Adjust this pattern to match your actual key format
     */
    private boolean isValidFormat(String key) {
        // Accept keys like: DXBANS-XXXXXXXX-XXXXXXXX-XXXX or any reasonable format
        return key.length() >= 16 && key.contains("-");
    }

    /**
     * SHA-256 hash of the license key - used for secure transmission
     */
    public static String hashKey(String key) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(key.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            return Base64.getEncoder().encodeToString(key.getBytes(StandardCharsets.UTF_8));
        }
    }

    /**
     * Generate a unique server ID based on server folder name + system properties
     * Used to bind license to a specific server
     */
    private String getServerId() {
        try {
            String raw = plugin.getDataFolder().getAbsolutePath()
                    + System.getProperty("os.name", "")
                    + System.getProperty("user.name", "");
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString().substring(0, 16);
        } catch (Exception e) {
            return "unknown";
        }
    }

    /**
     * Save validated key hash to cache file for offline grace period
     */
    private void saveLicenseCache(String key) {
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            try (FileWriter fw = new FileWriter(cacheFile)) {
                // Store hashed key + timestamp - NEVER the raw key
                fw.write(hashKey(key) + "\n" + System.currentTimeMillis());
            }
        } catch (IOException ignored) {}
    }

    /**
     * Load license cache and verify it matches current key
     */
    private boolean loadFromCache(String key) {
        if (!cacheFile.exists()) return false;
        try (BufferedReader br = new BufferedReader(new FileReader(cacheFile))) {
            String cachedHash = br.readLine();
            String timestampStr = br.readLine();
            if (cachedHash != null && timestampStr != null) {
                if (cachedHash.equals(hashKey(key))) {
                    lastValidated = Long.parseLong(timestampStr.trim());
                    return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    public boolean isValid() { return valid; }

    // NEVER expose the raw license key
    public String getMaskedKey() {
        if (licenseKey == null || licenseKey.length() < 8) return "****";
        return licenseKey.substring(0, 4) + "-****-****-" + licenseKey.substring(licenseKey.length() - 4);
    }
}
