package dev.dxbans.tasks;

import dev.dxbans.DxBans;
import org.bukkit.scheduler.BukkitRunnable;

public class ExpiredPunishmentTask extends BukkitRunnable {

    private final DxBans plugin;

    public ExpiredPunishmentTask(DxBans plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        if (!plugin.isLicenseValid()) return;
        plugin.getBanManager().expireActiveBans();
        plugin.getMuteManager().expireActiveMutes();
    }
}
