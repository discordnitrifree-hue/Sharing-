package dev.dxbans.utils;

import dev.dxbans.DxBans;

public class ConfigUtil {

    private final DxBans plugin;
    public final MessageUtil messages;

    public ConfigUtil(DxBans plugin) {
        this.plugin = plugin;
        this.messages = new MessageUtil(plugin);
    }

    public void reload() {
        plugin.reloadConfig();
        messages.reload();
    }

    public String getDefaultReason(String type) {
        return plugin.getConfig().getString("punishments." + type + ".default-reason", "No reason provided.");
    }

    public boolean shouldBroadcast(String type) {
        return plugin.getConfig().getBoolean("punishments." + type + ".broadcast", true);
    }

    public String getBroadcastFormat(String type) {
        return plugin.getConfig().getString("broadcast.formats." + type, "");
    }

    public String getServerName() {
        return plugin.getConfig().getString("general.server-name", "Server");
    }

    public int getEntriesPerPage() {
        return plugin.getConfig().getInt("general.entries-per-page", 10);
    }

    public boolean isGeoIpEnabled() {
        return plugin.getConfig().getBoolean("geoip.enabled", true);
    }

    public boolean isAltDetectionEnabled() {
        return plugin.getConfig().getBoolean("alt-detection.enabled", true);
    }

    public boolean isFreezeEnabled() {
        return plugin.getConfig().getBoolean("freeze.enabled", true);
    }

    public boolean isShadowBanEnabled() {
        return plugin.getConfig().getBoolean("shadowban.enabled", true);
    }

    public String resolveReason(String input) {
        if (input == null || input.isEmpty()) return null;
        if (input.startsWith("#")) {
            String shortcut = input.substring(1).toLowerCase();
            String resolved = plugin.getConfig().getString("reason-shortcuts." + shortcut);
            return resolved != null ? resolved : input;
        }
        return input;
    }
}
