package dev.dxbans.utils;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DurationUtil {

    private static final Pattern DURATION_PATTERN = Pattern.compile("(\\d+)(s|sec|m|min|h|hr|d|day|w|week|mo|month|y|year)s?", Pattern.CASE_INSENSITIVE);

    /**
     * Parses duration string like "1d", "7d", "1mo", "2h30m" into milliseconds.
     * Returns -1 for permanent ("perm", "permanent", "-1", "0").
     */
    public static long parse(String input) {
        if (input == null) return -1;
        input = input.trim().toLowerCase();

        if (input.equals("perm") || input.equals("permanent") || input.equals("-1") || input.equals("0")) {
            return -1;
        }

        Matcher matcher = DURATION_PATTERN.matcher(input);
        long totalMs = 0;
        boolean found = false;

        while (matcher.find()) {
            found = true;
            long value = Long.parseLong(matcher.group(1));
            String unit = matcher.group(2).toLowerCase();

            totalMs += switch (unit) {
                case "s", "sec"          -> TimeUnit.SECONDS.toMillis(value);
                case "m", "min"          -> TimeUnit.MINUTES.toMillis(value);
                case "h", "hr"           -> TimeUnit.HOURS.toMillis(value);
                case "d", "day"          -> TimeUnit.DAYS.toMillis(value);
                case "w", "week"         -> TimeUnit.DAYS.toMillis(value * 7);
                case "mo", "month"       -> TimeUnit.DAYS.toMillis(value * 30);
                case "y", "year"         -> TimeUnit.DAYS.toMillis(value * 365);
                default                  -> 0L;
            };
        }

        return found ? totalMs : -1;
    }

    /**
     * Formats milliseconds into a human-readable duration string.
     * e.g. 90061000 → "1d 1h 1m 1s"
     */
    public static String format(long millis) {
        if (millis <= 0) return "Permanent";

        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours   = minutes / 60;
        long days    = hours / 24;
        long years   = days / 365;
        days  = days % 365;
        long months  = days / 30;
        days  = days % 30;
        hours   = hours % 24;
        minutes = minutes % 60;
        seconds = seconds % 60;

        StringBuilder sb = new StringBuilder();
        if (years > 0)   sb.append(years).append("y ");
        if (months > 0)  sb.append(months).append("mo ");
        if (days > 0)    sb.append(days).append("d ");
        if (hours > 0)   sb.append(hours).append("h ");
        if (minutes > 0) sb.append(minutes).append("m ");
        if (seconds > 0) sb.append(seconds).append("s");

        return sb.toString().trim();
    }

    /**
     * Formats remaining time until timestamp
     */
    public static String formatRemaining(long until) {
        if (until == -1) return "Permanent";
        long remaining = until - System.currentTimeMillis();
        if (remaining <= 0) return "Expired";
        return format(remaining);
    }

    public static boolean isPermanent(String input) {
        return parse(input) == -1;
    }
}
