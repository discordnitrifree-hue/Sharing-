package dev.dxbans.utils;

import net.md_5.bungee.api.ChatColor;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ╔══════════════════════════════════════════════════════╗
 * ║        DxBans — GradientUtil                         ║
 * ║  Supports:                                           ║
 * ║  <gradient:#FF0000:#0000FF>text</gradient>           ║
 * ║  <rainbow>text</rainbow>                             ║
 * ║  <fire>text</fire>                                   ║
 * ║  <ice>text</ice>                                     ║
 * ║  <gold>text</gold>                                   ║
 * ║  <neon>text</neon>                                   ║
 * ║  <sunset>text</sunset>                               ║
 * ║  <ocean>text</ocean>                                 ║
 * ║  <toxic>text</toxic>                                 ║
 * ║  <void>text</void>                                   ║
 * ╚══════════════════════════════════════════════════════╝
 */
public class GradientUtil {

    // ─── PATTERNS ────────────────────────────────────────────────────────────
    private static final Pattern GRADIENT_PATTERN =
            Pattern.compile("<gradient:(#[A-Fa-f0-9]{6}):(#[A-Fa-f0-9]{6})>(.*?)</gradient>", Pattern.DOTALL);
    private static final Pattern GRADIENT_MULTI_PATTERN =
            Pattern.compile("<gradient:((?:#[A-Fa-f0-9]{6}:?)+)>(.*?)</gradient>", Pattern.DOTALL);
    private static final Pattern RAINBOW_PATTERN =
            Pattern.compile("<rainbow>(.*?)</rainbow>", Pattern.DOTALL);

    // Preset gradients
    private static final Pattern FIRE_PATTERN    = Pattern.compile("<fire>(.*?)</fire>", Pattern.DOTALL);
    private static final Pattern ICE_PATTERN     = Pattern.compile("<ice>(.*?)</ice>", Pattern.DOTALL);
    private static final Pattern GOLD_PATTERN    = Pattern.compile("<gold>(.*?)</gold>", Pattern.DOTALL);
    private static final Pattern NEON_PATTERN    = Pattern.compile("<neon>(.*?)</neon>", Pattern.DOTALL);
    private static final Pattern SUNSET_PATTERN  = Pattern.compile("<sunset>(.*?)</sunset>", Pattern.DOTALL);
    private static final Pattern OCEAN_PATTERN   = Pattern.compile("<ocean>(.*?)</ocean>", Pattern.DOTALL);
    private static final Pattern TOXIC_PATTERN   = Pattern.compile("<toxic>(.*?)</toxic>", Pattern.DOTALL);
    private static final Pattern VOID_PATTERN    = Pattern.compile("<void>(.*?)</void>", Pattern.DOTALL);
    private static final Pattern CANDY_PATTERN   = Pattern.compile("<candy>(.*?)</candy>", Pattern.DOTALL);
    private static final Pattern AURORA_PATTERN  = Pattern.compile("<aurora>(.*?)</aurora>", Pattern.DOTALL);
    private static final Pattern BLOOD_PATTERN   = Pattern.compile("<blood>(.*?)</blood>", Pattern.DOTALL);
    private static final Pattern GALAXY_PATTERN  = Pattern.compile("<galaxy>(.*?)</galaxy>", Pattern.DOTALL);

    // ─── PRESET COLOR STOPS ──────────────────────────────────────────────────
    private static final String[] FIRE_COLORS    = {"#FF0000", "#FF4400", "#FF8800", "#FFAA00", "#FFCC00"};
    private static final String[] ICE_COLORS     = {"#00CFFF", "#00AAFF", "#0077FF", "#00EEFF", "#AAFFFF"};
    private static final String[] GOLD_COLORS    = {"#FFD700", "#FFA500", "#FFE066", "#FFBF00", "#FFC200"};
    private static final String[] NEON_COLORS    = {"#FF00FF", "#FF0099", "#9900FF", "#0099FF", "#00FFFF"};
    private static final String[] SUNSET_COLORS  = {"#FF6B35", "#F7931E", "#FFD700", "#FF69B4", "#C71585"};
    private static final String[] OCEAN_COLORS   = {"#006994", "#0099CC", "#00CED1", "#20B2AA", "#48D1CC"};
    private static final String[] TOXIC_COLORS   = {"#39FF14", "#7FFF00", "#ADFF2F", "#00FF7F", "#00FA9A"};
    private static final String[] VOID_COLORS    = {"#2D0057", "#4B0082", "#7B00D4", "#9400D3", "#8A2BE2"};
    private static final String[] CANDY_COLORS   = {"#FF6EFF", "#FF85A1", "#FFC6FF", "#BFEFFF", "#98FB98"};
    private static final String[] AURORA_COLORS  = {"#00FF87", "#60EFFF", "#0061FF", "#FF00C7", "#FF8C00"};
    private static final String[] BLOOD_COLORS   = {"#8B0000", "#CC0000", "#FF0000", "#B22222", "#DC143C"};
    private static final String[] GALAXY_COLORS  = {"#1A0533", "#6A0DAD", "#9B59B6", "#00CED1", "#FFFFFF"};
    private static final String[] RAINBOW_COLORS = {"#FF0000", "#FF7700", "#FFFF00", "#00FF00", "#0000FF", "#8B00FF"};

    // ─── MAIN PARSE METHOD ───────────────────────────────────────────────────
    /**
     * Parses all gradient/rainbow/preset tags in a string and returns colored output.
     * Also handles & color codes and &#RRGGBB hex.
     */
    public static String parse(String text) {
        if (text == null) return "";

        // Apply preset gradients
        text = applyPreset(text, FIRE_PATTERN,   FIRE_COLORS);
        text = applyPreset(text, ICE_PATTERN,    ICE_COLORS);
        text = applyPreset(text, GOLD_PATTERN,   GOLD_COLORS);
        text = applyPreset(text, NEON_PATTERN,   NEON_COLORS);
        text = applyPreset(text, SUNSET_PATTERN, SUNSET_COLORS);
        text = applyPreset(text, OCEAN_PATTERN,  OCEAN_COLORS);
        text = applyPreset(text, TOXIC_PATTERN,  TOXIC_COLORS);
        text = applyPreset(text, VOID_PATTERN,   VOID_COLORS);
        text = applyPreset(text, CANDY_PATTERN,  CANDY_COLORS);
        text = applyPreset(text, AURORA_PATTERN, AURORA_COLORS);
        text = applyPreset(text, BLOOD_PATTERN,  BLOOD_COLORS);
        text = applyPreset(text, GALAXY_PATTERN, GALAXY_COLORS);

        // Apply rainbow
        text = applyPreset(text, RAINBOW_PATTERN, RAINBOW_COLORS);

        // Apply custom 2-color gradient: <gradient:#RRGGBB:#RRGGBB>text</gradient>
        Matcher m2 = GRADIENT_PATTERN.matcher(text);
        StringBuffer sb2 = new StringBuffer();
        while (m2.find()) {
            String hex1    = m2.group(1);
            String hex2    = m2.group(2);
            String content = m2.group(3);
            m2.appendReplacement(sb2, Matcher.quoteReplacement(
                    applyGradient(content, new String[]{hex1, hex2})
            ));
        }
        m2.appendTail(sb2);
        text = sb2.toString();

        // Apply standard & and &#hex colors
        return ColorUtil.color(text);
    }

    // ─── APPLY PRESET ────────────────────────────────────────────────────────
    private static String applyPreset(String text, Pattern pattern, String[] colors) {
        Matcher m = pattern.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String content = m.group(1);
            m.appendReplacement(sb, Matcher.quoteReplacement(applyGradient(content, colors)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    // ─── CORE GRADIENT LOGIC ─────────────────────────────────────────────────
    /**
     * Applies a multi-stop gradient to a string of text.
     * Preserves existing formatting codes on each character.
     */
    public static String applyGradient(String text, String[] hexColors) {
        if (text == null || text.isEmpty()) return text;

        // Strip existing color for clean gradient
        String stripped = ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&', text));
        if (stripped.isEmpty()) return text;

        // Parse all color stops into AWT Colors
        Color[] colors = new Color[hexColors.length];
        for (int i = 0; i < hexColors.length; i++) {
            colors[i] = hexToColor(hexColors[i]);
        }

        // Build gradient character by character
        char[] chars = stripped.toCharArray();
        int len = chars.length;
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < len; i++) {
            // Position 0.0 → 1.0
            float progress = len == 1 ? 0f : (float) i / (len - 1);

            // Find which segment this character falls in
            float segmentSize = 1.0f / (colors.length - 1);
            int segmentIndex = Math.min((int) (progress / segmentSize), colors.length - 2);
            float segmentProgress = (progress - segmentIndex * segmentSize) / segmentSize;

            Color c = interpolate(colors[segmentIndex], colors[segmentIndex + 1], segmentProgress);
            result.append(colorToMinecraft(c));
            result.append(chars[i]);
        }

        return result.toString();
    }

    // ─── HELPERS ─────────────────────────────────────────────────────────────

    /** Linear interpolation between two colors */
    private static Color interpolate(Color a, Color b, float t) {
        int r = (int) (a.getRed()   + (b.getRed()   - a.getRed())   * t);
        int g = (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t);
        int bl = (int) (a.getBlue()  + (b.getBlue()  - a.getBlue())  * t);
        return new Color(
                Math.max(0, Math.min(255, r)),
                Math.max(0, Math.min(255, g)),
                Math.max(0, Math.min(255, bl))
        );
    }

    /** Convert hex string to AWT Color */
    private static Color hexToColor(String hex) {
        hex = hex.replace("#", "").replace("&", "");
        if (hex.length() == 6) {
            return new Color(
                    Integer.parseInt(hex.substring(0, 2), 16),
                    Integer.parseInt(hex.substring(2, 4), 16),
                    Integer.parseInt(hex.substring(4, 6), 16)
            );
        }
        return Color.WHITE;
    }

    /** Convert AWT Color to Minecraft §x§R§R§G§G§B§B format */
    private static String colorToMinecraft(Color c) {
        return net.md_5.bungee.api.ChatColor.of(
                String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue())
        ).toString();
    }

    /**
     * Generate a gradient string directly from two hex colors.
     * Convenience method.
     */
    public static String gradient(String text, String fromHex, String toHex) {
        return applyGradient(text, new String[]{fromHex, toHex});
    }

    /**
     * Generate rainbow text
     */
    public static String rainbow(String text) {
        return applyGradient(text, RAINBOW_COLORS);
    }

    /**
     * Generate fire text
     */
    public static String fire(String text) {
        return applyGradient(text, FIRE_COLORS);
    }

    /**
     * Generate ice text
     */
    public static String ice(String text) {
        return applyGradient(text, ICE_COLORS);
    }

    /**
     * Generate gold text
     */
    public static String gold(String text) {
        return applyGradient(text, GOLD_COLORS);
    }

    /**
     * Generate neon text
     */
    public static String neon(String text) {
        return applyGradient(text, NEON_COLORS);
    }

    /**
     * Generate void/purple text
     */
    public static String voidGradient(String text) {
        return applyGradient(text, VOID_COLORS);
    }
}
