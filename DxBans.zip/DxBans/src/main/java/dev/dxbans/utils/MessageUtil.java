package dev.dxbans.utils;

import dev.dxbans.DxBans;
import dev.dxbans.utils.GradientUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class MessageUtil {

    private final DxBans plugin;
    private FileConfiguration messages;
    private File messagesFile;

    public MessageUtil(DxBans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(messagesFile);
    }

    /**
     * Gets a message from messages.yml, applies prefix, gradient tags, and color codes.
     */
    public String get(String key) {
        String prefix = GradientUtil.parse(messages.getString("prefix", "<gradient:#FF0000:#FF8800>DxBans</gradient>"));
        String msg = messages.getString(key, "&cMissing message: " + key);
        return GradientUtil.parse(msg.replace("{prefix}", prefix));
    }

    /**
     * Gets message and replaces placeholders.
     * Placeholders come in pairs: "key", "value", "key2", "value2"...
     */
    public String get(String key, String... replacements) {
        String msg = get(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace("{" + replacements[i] + "}", replacements[i + 1]);
        }
        return msg;
    }

    /**
     * Sends a message to a CommandSender
     */
    public void send(CommandSender sender, String key, String... replacements) {
        sender.sendMessage(get(key, replacements));
    }

    /**
     * Formats a timestamp into the configured date format
     */
    public String formatDate(long timestamp) {
        if (timestamp <= 0) return "Never";
        String format = plugin.getConfig().getString("general.date-format", "dd/MM/yyyy HH:mm:ss");
        String timezone = plugin.getConfig().getString("general.timezone", "UTC");
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setTimeZone(TimeZone.getTimeZone(timezone));
        return sdf.format(new Date(timestamp));
    }
}
