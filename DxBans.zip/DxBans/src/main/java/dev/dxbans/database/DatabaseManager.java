package dev.dxbans.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import dev.dxbans.DxBans;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.sql.*;
import java.util.logging.Level;

public class DatabaseManager {

    private final DxBans plugin;
    private HikariDataSource dataSource;
    private String dbType;
    private String tablePrefix;

    public DatabaseManager(DxBans plugin) {
        this.plugin = plugin;
    }

    public boolean connect() {
        FileConfiguration config = plugin.getConfig();
        dbType = config.getString("database.type", "sqlite").toLowerCase();
        tablePrefix = config.getString("database.mysql.prefix", "dxbans_");

        HikariConfig hikariConfig = new HikariConfig();

        try {
            if (dbType.equals("sqlite")) {
                File dbFile = new File(plugin.getDataFolder(), config.getString("database.sqlite.file", "dxbans.db"));
                if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();

                hikariConfig.setDriverClassName("org.sqlite.JDBC");
                hikariConfig.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
                hikariConfig.setMaximumPoolSize(1);
                hikariConfig.setConnectionTestQuery("SELECT 1");

            } else {
                // MySQL / MariaDB
                String host     = config.getString("database.mysql.host", "localhost");
                int    port     = config.getInt("database.mysql.port", 3306);
                String database = config.getString("database.mysql.database", "dxbans");
                String username = config.getString("database.mysql.username", "root");
                String password = config.getString("database.mysql.password", "");
                boolean ssl     = config.getBoolean("database.mysql.ssl", false);

                hikariConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
                hikariConfig.setJdbcUrl("jdbc:mysql://" + host + ":" + port + "/" + database
                        + "?useSSL=" + ssl + "&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8");
                hikariConfig.setUsername(username);
                hikariConfig.setPassword(password);

                hikariConfig.setMaximumPoolSize(config.getInt("database.mysql.pool.maximum-pool-size", 10));
                hikariConfig.setMinimumIdle(config.getInt("database.mysql.pool.minimum-idle", 5));
                hikariConfig.setConnectionTimeout(config.getLong("database.mysql.pool.connection-timeout", 30000));
                hikariConfig.setIdleTimeout(config.getLong("database.mysql.pool.idle-timeout", 600000));
                hikariConfig.setMaxLifetime(config.getLong("database.mysql.pool.max-lifetime", 1800000));
            }

            hikariConfig.setPoolName("DxBans-Pool");
            hikariConfig.addDataSourceProperty("cachePrepStmts", "true");
            hikariConfig.addDataSourceProperty("prepStmtCacheSize", "250");
            hikariConfig.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

            dataSource = new HikariDataSource(hikariConfig);
            return true;

        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to connect to database!", e);
            return false;
        }
    }

    public void createTables() {
        String bansTable = isSqlite() ?
            "CREATE TABLE IF NOT EXISTS " + t("bans") + " (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  uuid TEXT NOT NULL," +
            "  name TEXT NOT NULL," +
            "  ip TEXT," +
            "  reason TEXT NOT NULL," +
            "  operator TEXT NOT NULL," +
            "  operator_uuid TEXT," +
            "  date BIGINT NOT NULL," +
            "  until BIGINT DEFAULT -1," +
            "  server TEXT," +
            "  active INTEGER DEFAULT 1," +
            "  removed_by TEXT," +
            "  removed_date BIGINT," +
            "  ip_ban INTEGER DEFAULT 0," +
            "  silent INTEGER DEFAULT 0," +
            "  type TEXT DEFAULT 'ban'" +
            ")" :
            "CREATE TABLE IF NOT EXISTS " + t("bans") + " (" +
            "  id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "  uuid VARCHAR(36) NOT NULL," +
            "  name VARCHAR(32) NOT NULL," +
            "  ip VARCHAR(45)," +
            "  reason TEXT NOT NULL," +
            "  operator VARCHAR(32) NOT NULL," +
            "  operator_uuid VARCHAR(36)," +
            "  date BIGINT NOT NULL," +
            "  until BIGINT DEFAULT -1," +
            "  server VARCHAR(64)," +
            "  active TINYINT(1) DEFAULT 1," +
            "  removed_by VARCHAR(32)," +
            "  removed_date BIGINT," +
            "  ip_ban TINYINT(1) DEFAULT 0," +
            "  silent TINYINT(1) DEFAULT 0," +
            "  type VARCHAR(16) DEFAULT 'ban'" +
            ") CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

        String mutesTable = isSqlite() ?
            "CREATE TABLE IF NOT EXISTS " + t("mutes") + " (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  uuid TEXT NOT NULL," +
            "  name TEXT NOT NULL," +
            "  reason TEXT NOT NULL," +
            "  operator TEXT NOT NULL," +
            "  operator_uuid TEXT," +
            "  date BIGINT NOT NULL," +
            "  until BIGINT DEFAULT -1," +
            "  server TEXT," +
            "  active INTEGER DEFAULT 1," +
            "  removed_by TEXT," +
            "  removed_date BIGINT," +
            "  silent INTEGER DEFAULT 0," +
            "  type TEXT DEFAULT 'mute'" +
            ")" :
            "CREATE TABLE IF NOT EXISTS " + t("mutes") + " (" +
            "  id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "  uuid VARCHAR(36) NOT NULL," +
            "  name VARCHAR(32) NOT NULL," +
            "  reason TEXT NOT NULL," +
            "  operator VARCHAR(32) NOT NULL," +
            "  operator_uuid VARCHAR(36)," +
            "  date BIGINT NOT NULL," +
            "  until BIGINT DEFAULT -1," +
            "  server VARCHAR(64)," +
            "  active TINYINT(1) DEFAULT 1," +
            "  removed_by VARCHAR(32)," +
            "  removed_date BIGINT," +
            "  silent TINYINT(1) DEFAULT 0," +
            "  type VARCHAR(16) DEFAULT 'mute'" +
            ") CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

        String warnsTable = isSqlite() ?
            "CREATE TABLE IF NOT EXISTS " + t("warnings") + " (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  uuid TEXT NOT NULL," +
            "  name TEXT NOT NULL," +
            "  reason TEXT NOT NULL," +
            "  operator TEXT NOT NULL," +
            "  operator_uuid TEXT," +
            "  date BIGINT NOT NULL," +
            "  until BIGINT DEFAULT -1," +
            "  server TEXT," +
            "  active INTEGER DEFAULT 1," +
            "  type TEXT DEFAULT 'warn'" +
            ")" :
            "CREATE TABLE IF NOT EXISTS " + t("warnings") + " (" +
            "  id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "  uuid VARCHAR(36) NOT NULL," +
            "  name VARCHAR(32) NOT NULL," +
            "  reason TEXT NOT NULL," +
            "  operator VARCHAR(32) NOT NULL," +
            "  operator_uuid VARCHAR(36)," +
            "  date BIGINT NOT NULL," +
            "  until BIGINT DEFAULT -1," +
            "  server VARCHAR(64)," +
            "  active TINYINT(1) DEFAULT 1," +
            "  type VARCHAR(16) DEFAULT 'warn'" +
            ") CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

        String historyTable = isSqlite() ?
            "CREATE TABLE IF NOT EXISTS " + t("history") + " (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  uuid TEXT NOT NULL," +
            "  name TEXT NOT NULL," +
            "  type TEXT NOT NULL," +
            "  reason TEXT," +
            "  operator TEXT NOT NULL," +
            "  date BIGINT NOT NULL," +
            "  duration BIGINT DEFAULT -1," +
            "  server TEXT," +
            "  ref_id BIGINT" +
            ")" :
            "CREATE TABLE IF NOT EXISTS " + t("history") + " (" +
            "  id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "  uuid VARCHAR(36) NOT NULL," +
            "  name VARCHAR(32) NOT NULL," +
            "  type VARCHAR(20) NOT NULL," +
            "  reason TEXT," +
            "  operator VARCHAR(32) NOT NULL," +
            "  date BIGINT NOT NULL," +
            "  duration BIGINT DEFAULT -1," +
            "  server VARCHAR(64)," +
            "  ref_id BIGINT" +
            ") CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

        String playersTable = isSqlite() ?
            "CREATE TABLE IF NOT EXISTS " + t("players") + " (" +
            "  uuid TEXT PRIMARY KEY," +
            "  name TEXT NOT NULL," +
            "  ip TEXT," +
            "  last_seen BIGINT," +
            "  first_seen BIGINT," +
            "  country TEXT," +
            "  shadowbanned INTEGER DEFAULT 0," +
            "  frozen INTEGER DEFAULT 0," +
            "  blacklisted INTEGER DEFAULT 0" +
            ")" :
            "CREATE TABLE IF NOT EXISTS " + t("players") + " (" +
            "  uuid VARCHAR(36) PRIMARY KEY," +
            "  name VARCHAR(32) NOT NULL," +
            "  ip VARCHAR(45)," +
            "  last_seen BIGINT," +
            "  first_seen BIGINT," +
            "  country VARCHAR(64)," +
            "  shadowbanned TINYINT(1) DEFAULT 0," +
            "  frozen TINYINT(1) DEFAULT 0," +
            "  blacklisted TINYINT(1) DEFAULT 0" +
            ") CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

        String ipHistoryTable = isSqlite() ?
            "CREATE TABLE IF NOT EXISTS " + t("ip_history") + " (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  uuid TEXT NOT NULL," +
            "  name TEXT NOT NULL," +
            "  ip TEXT NOT NULL," +
            "  date BIGINT NOT NULL" +
            ")" :
            "CREATE TABLE IF NOT EXISTS " + t("ip_history") + " (" +
            "  id BIGINT AUTO_INCREMENT PRIMARY KEY," +
            "  uuid VARCHAR(36) NOT NULL," +
            "  name VARCHAR(32) NOT NULL," +
            "  ip VARCHAR(45) NOT NULL," +
            "  date BIGINT NOT NULL" +
            ") CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

        try (Connection conn = getConnection()) {
            conn.createStatement().execute(bansTable);
            conn.createStatement().execute(mutesTable);
            conn.createStatement().execute(warnsTable);
            conn.createStatement().execute(historyTable);
            conn.createStatement().execute(playersTable);
            conn.createStatement().execute(ipHistoryTable);
            plugin.getLogger().info("Database tables created/verified.");
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to create database tables!", e);
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public void disconnect() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    public boolean isSqlite() {
        return dbType.equals("sqlite");
    }

    /** Returns prefixed table name */
    public String t(String table) {
        return tablePrefix + table;
    }
}
