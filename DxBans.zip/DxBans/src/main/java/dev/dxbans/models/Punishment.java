package dev.dxbans.models;

import java.util.UUID;

public class Punishment {

    public enum Type {
        BAN, TEMPBAN, BANIP, TEMPBANIP,
        MUTE, TEMPMUTE,
        WARN, TEMPWARN,
        KICK,
        SHADOWBAN, BLACKLIST
    }

    private long id;
    private UUID playerUUID;
    private String playerName;
    private String ip;
    private Type type;
    private String reason;
    private String operator;
    private UUID operatorUUID;
    private long date;
    private long until; // -1 = permanent
    private String server;
    private boolean active;
    private String removedBy;
    private long removedDate;
    private boolean silent;
    private boolean ipBan;

    public Punishment() {}

    public Punishment(UUID playerUUID, String playerName, Type type, String reason,
                      String operator, UUID operatorUUID, long date, long until, String server, boolean silent) {
        this.playerUUID   = playerUUID;
        this.playerName   = playerName;
        this.type         = type;
        this.reason       = reason;
        this.operator     = operator;
        this.operatorUUID = operatorUUID;
        this.date         = date;
        this.until        = until;
        this.server       = server;
        this.silent       = silent;
        this.active       = true;
    }

    public boolean isPermanent()  { return until == -1; }
    public boolean isExpired()    { return !isPermanent() && System.currentTimeMillis() > until; }
    public boolean isActive()     { return active && !isExpired(); }
    public boolean isTemporary()  { return until != -1; }
    public boolean isTempType()   { return type == Type.TEMPBAN || type == Type.TEMPBANIP || type == Type.TEMPMUTE || type == Type.TEMPWARN; }

    public long getRemainingTime() {
        if (isPermanent()) return -1;
        return Math.max(0, until - System.currentTimeMillis());
    }

    // ── GETTERS & SETTERS ────────────────────────────────────────
    public long getId()                      { return id; }
    public void setId(long id)               { this.id = id; }
    public UUID getPlayerUUID()              { return playerUUID; }
    public void setPlayerUUID(UUID uuid)     { this.playerUUID = uuid; }
    public String getPlayerName()            { return playerName; }
    public void setPlayerName(String name)   { this.playerName = name; }
    public String getIp()                    { return ip; }
    public void setIp(String ip)             { this.ip = ip; }
    public Type getType()                    { return type; }
    public void setType(Type type)           { this.type = type; }
    public String getReason()                { return reason; }
    public void setReason(String reason)     { this.reason = reason; }
    public String getOperator()              { return operator; }
    public void setOperator(String op)       { this.operator = op; }
    public UUID getOperatorUUID()            { return operatorUUID; }
    public void setOperatorUUID(UUID uuid)   { this.operatorUUID = uuid; }
    public long getDate()                    { return date; }
    public void setDate(long date)           { this.date = date; }
    public long getUntil()                   { return until; }
    public void setUntil(long until)         { this.until = until; }
    public String getServer()                { return server; }
    public void setServer(String server)     { this.server = server; }
    public boolean isActiveField()           { return active; }
    public void setActive(boolean active)    { this.active = active; }
    public String getRemovedBy()             { return removedBy; }
    public void setRemovedBy(String by)      { this.removedBy = by; }
    public long getRemovedDate()             { return removedDate; }
    public void setRemovedDate(long date)    { this.removedDate = date; }
    public boolean isSilent()               { return silent; }
    public void setSilent(boolean silent)    { this.silent = silent; }
    public boolean isIpBan()                { return ipBan; }
    public void setIpBan(boolean ipBan)     { this.ipBan = ipBan; }
}
