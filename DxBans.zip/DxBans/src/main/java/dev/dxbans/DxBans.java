package dev.dxbans;

import dev.dxbans.commands.*;
import dev.dxbans.database.DatabaseManager;
import dev.dxbans.license.LicenseManager;
import dev.dxbans.listeners.*;
import dev.dxbans.managers.*;
import dev.dxbans.placeholders.DxBansPlaceholders;
import dev.dxbans.tasks.ExpiredPunishmentTask;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.ConfigUtil;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public class DxBans extends JavaPlugin {

    private static DxBans instance;

    private DatabaseManager databaseManager;
    private BanManager banManager;
    private MuteManager muteManager;
    private WarnManager warnManager;
    private FreezeManager freezeManager;
    private ShadowBanManager shadowBanManager;
    private AltManager altManager;
    private GeoIPManager geoIPManager;
    private LicenseManager licenseManager;
    private ConfigUtil configUtil;
    private HistoryManager historyManager;

    private boolean licenseValid = false;

    @Override
    public void onEnable() {
        instance = this;

        printBanner();

        // Save default config files
        saveDefaultConfig();
        saveResource("messages.yml", false);

        configUtil = new ConfigUtil(this);

        // ── LICENSE CHECK ────────────────────────────────
        licenseManager = new LicenseManager(this);
        licenseValid = licenseManager.validate();

        if (!licenseValid) {
            getLogger().severe("══════════════════════════════════════════");
            getLogger().severe(" DxBans is DISABLED - Invalid License Key!");
            getLogger().severe(" Enter your license key in config.yml");
            getLogger().severe(" Get a key at: https://dxbans.dev/license");
            getLogger().severe("══════════════════════════════════════════");
            // Plugin stays loaded but all features are disabled
            // Players will see disabled message on join
            registerListenerLicenseOnly();
            return;
        }

        getLogger().info("License validated successfully!");

        // ── DATABASE ─────────────────────────────────────
        databaseManager = new DatabaseManager(this);
        if (!databaseManager.connect()) {
            getLogger().severe("Failed to connect to database! Disabling plugin.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        databaseManager.createTables();
        getLogger().info("Database connected successfully.");

        // ── MANAGERS ─────────────────────────────────────
        banManager       = new BanManager(this);
        muteManager      = new MuteManager(this);
        warnManager      = new WarnManager(this);
        freezeManager    = new FreezeManager(this);
        shadowBanManager = new ShadowBanManager(this);
        altManager       = new AltManager(this);
        geoIPManager     = new GeoIPManager(this);
        historyManager   = new HistoryManager(this);

        // ── COMMANDS ─────────────────────────────────────
        registerCommands();

        // ── LISTENERS ────────────────────────────────────
        registerListeners();

        // ── PLACEHOLDERS ─────────────────────────────────
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new DxBansPlaceholders(this).register();
            getLogger().info("PlaceholderAPI hooked successfully.");
        }

        // ── TASKS ─────────────────────────────────────────
        new ExpiredPunishmentTask(this).runTaskTimerAsynchronously(this, 20L * 30, 20L * 30);

        // ── LICENSE RECHECK TASK ──────────────────────────
        int checkInterval = getConfig().getInt("license.check-interval", 60) * 60 * 20;
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> licenseManager.validate(), checkInterval, checkInterval);

        getLogger().info("DxBans v" + getDescription().getVersion() + " enabled successfully!");
        getLogger().info("Platform: " + getPlatformName() + " | MC: " + Bukkit.getBukkitVersion());
    }

    @Override
    public void onDisable() {
        if (databaseManager != null) {
            databaseManager.disconnect();
        }
        getLogger().info("DxBans disabled.");
    }

    private void registerCommands() {
        // Ban Commands
        getCommand("ban").setExecutor(new BanCommand(this));
        getCommand("banip").setExecutor(new BanIpCommand(this));
        getCommand("tempban").setExecutor(new TempBanCommand(this));
        getCommand("tempbanip").setExecutor(new TempBanIpCommand(this));
        getCommand("unban").setExecutor(new UnbanCommand(this));
        getCommand("unbanip").setExecutor(new UnbanIpCommand(this));
        // Mute Commands
        getCommand("mute").setExecutor(new MuteCommand(this));
        getCommand("tempmute").setExecutor(new TempMuteCommand(this));
        getCommand("unmute").setExecutor(new UnmuteCommand(this));
        // Warn Commands
        getCommand("warn").setExecutor(new WarnCommand(this));
        getCommand("tempwarn").setExecutor(new TempWarnCommand(this));
        getCommand("unwarn").setExecutor(new UnwarnCommand(this));
        // Kick Commands
        getCommand("kick").setExecutor(new KickCommand(this));
        getCommand("masskick").setExecutor(new MassKickCommand(this));
        // Info Commands
        getCommand("history").setExecutor(new HistoryCommand(this));
        getCommand("baninfo").setExecutor(new BanInfoCommand(this));
        getCommand("muteinfo").setExecutor(new MuteInfoCommand(this));
        getCommand("banlist").setExecutor(new BanListCommand(this));
        getCommand("mutelist").setExecutor(new MuteListCommand(this));
        getCommand("warnlist").setExecutor(new WarnListCommand(this));
        getCommand("ipinfo").setExecutor(new IpInfoCommand(this));
        getCommand("alts").setExecutor(new AltsCommand(this));
        getCommand("geoip").setExecutor(new GeoIpCommand(this));
        getCommand("staffhistory").setExecutor(new StaffHistoryCommand(this));
        // Special Commands
        getCommand("shadowban").setExecutor(new ShadowBanCommand(this));
        getCommand("freeze").setExecutor(new FreezeCommand(this));
        getCommand("blacklist").setExecutor(new BlacklistCommand(this));
        getCommand("clearhistory").setExecutor(new ClearHistoryCommand(this));
        // Admin
        getCommand("dxbans").setExecutor(new DxBansCommand(this));
    }

    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerLoginListener(this), this);
        Bukkit.getPluginManager().registerEvents(new AsyncChatListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CommandListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerMoveListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerQuitListener(this), this);
    }

    private void registerListenerLicenseOnly() {
        Bukkit.getPluginManager().registerEvents(new LicenseBlockListener(this), this);
    }

    private void printBanner() {
        getLogger().info("╔════════════════════════════════╗");
        getLogger().info("║         DxBans v1.0.0          ║");
        getLogger().info("║   Advanced Punishment Plugin   ║");
        getLogger().info("║   1.19 → 1.21.11 Support      ║");
        getLogger().info("╚════════════════════════════════╝");
    }

    private String getPlatformName() {
        try {
            Class.forName("io.papermc.paper.configuration.Configuration");
            return "PaperMC";
        } catch (ClassNotFoundException ignored) {}
        try {
            Class.forName("com.destroystokyo.paper.PaperConfig");
            return "PaperMC (Legacy)";
        } catch (ClassNotFoundException ignored) {}
        try {
            Class.forName("org.purpurmc.purpur.PurpurConfig");
            return "Purpur";
        } catch (ClassNotFoundException ignored) {}
        return "SpigotMC";
    }

    public static DxBans getInstance() { return instance; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public BanManager getBanManager() { return banManager; }
    public MuteManager getMuteManager() { return muteManager; }
    public WarnManager getWarnManager() { return warnManager; }
    public FreezeManager getFreezeManager() { return freezeManager; }
    public ShadowBanManager getShadowBanManager() { return shadowBanManager; }
    public AltManager getAltManager() { return altManager; }
    public GeoIPManager getGeoIPManager() { return geoIPManager; }
    public LicenseManager getLicenseManager() { return licenseManager; }
    public ConfigUtil getConfigUtil() { return configUtil; }
    public HistoryManager getHistoryManager() { return historyManager; }
    public boolean isLicenseValid() { return licenseValid; }
    public void setLicenseValid(boolean valid) { this.licenseValid = valid; }
}
