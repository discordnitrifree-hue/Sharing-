package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class ShadowBanCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    public ShadowBanCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.shadowban")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /shadowban <player> [reason]")); return true; }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) { plugin.getConfigUtil().messages.send(sender, "player-online-only"); return true; }
        String reason = args.length > 1 ? String.join(" ", Arrays.copyOfRange(args, 1, args.length)) : "Shadowbanned";
        String op = sender instanceof Player ? sender.getName() : "Console";
        plugin.getShadowBanManager().shadowBan(target.getUniqueId(), target.getName(), reason, op);
        plugin.getConfigUtil().messages.send(sender, "shadowban-success", "player", target.getName(), "staff", op);
        // Notify all staff silently
        String perm = plugin.getConfig().getString("shadowban.staff-see-permission", "dxbans.shadowban.see");
        String msg = ColorUtil.color("&8[&4ShadowBan&8] &f" + op + " &7shadowbanned &f" + target.getName() + " &8(silent)");
        Bukkit.getOnlinePlayers().forEach(p -> { if (p.hasPermission(perm)) p.sendMessage(msg); });
        // Hide from non-staff
        if (plugin.getConfig().getBoolean("shadowban.hide-from-player-list", true)) {
            Bukkit.getOnlinePlayers().forEach(p -> { if (!p.hasPermission(perm)) p.hidePlayer(plugin, target); });
        }
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }
}
