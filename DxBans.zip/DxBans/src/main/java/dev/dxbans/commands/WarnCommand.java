package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class WarnCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    public WarnCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.warn")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /warn <player> [reason]")); return true; }
        Player target = Bukkit.getPlayerExact(args[0]);
        String reason = args.length > 1 ? String.join(" ", Arrays.copyOfRange(args, 1, args.length)) : plugin.getConfigUtil().getDefaultReason("warn");
        reason = plugin.getConfigUtil().resolveReason(reason);
        if (target == null) { plugin.getConfigUtil().messages.send(sender, "player-online-only"); return true; }
        String op = sender instanceof Player ? sender.getName() : "Console";
        UUID opUUID = sender instanceof Player ? ((Player)sender).getUniqueId() : null;
        final String fr = reason;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getWarnManager().warn(target.getUniqueId(), target.getName(), fr, op, opUUID, plugin.getConfigUtil().getServerName());
            int count = plugin.getWarnManager().getActiveWarnCount(target.getUniqueId());
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getConfigUtil().messages.send(sender, "warn-success", "player", target.getName(), "staff", op);
                target.sendMessage(plugin.getConfigUtil().messages.get("warn-received", "staff", op, "reason", fr, "count", String.valueOf(count)));
                if (plugin.getConfigUtil().shouldBroadcast("warn")) {
                    String msg = ColorUtil.color(plugin.getConfigUtil().getBroadcastFormat("warn").replace("{player}", target.getName()).replace("{staff}", op).replace("{reason}", fr));
                    if (!msg.isEmpty()) Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(msg));
                }
            });
        });
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }
}
