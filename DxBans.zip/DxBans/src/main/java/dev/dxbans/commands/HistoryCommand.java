package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class HistoryCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    public HistoryCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.history")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /history <player> [page]")); return true; }
        String targetName = args[0];
        int page = args.length > 1 ? parseInt(args[1], 1) : 1;
        int perPage = plugin.getConfigUtil().getEntriesPerPage();

        @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(targetName);
        if (!off.hasPlayedBefore() && off.getName() == null) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", targetName); return true; }
        UUID uuid = off.getUniqueId();

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<Punishment> history = plugin.getHistoryManager().getHistory(uuid, page, perPage);
            int total = plugin.getHistoryManager().getHistoryCount(uuid);
            int totalPages = (int) Math.ceil((double) total / perPage);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (history.isEmpty() && page == 1) {
                    plugin.getConfigUtil().messages.send(sender, "history-empty", "player", targetName);
                    return;
                }
                sender.sendMessage(plugin.getConfigUtil().messages.get("history-header", "player", targetName));
                for (Punishment p : history) {
                    String type = p.getType().name().toLowerCase();
                    String entry = plugin.getConfigUtil().messages.get("history-entry",
                            "id", String.valueOf(p.getId()),
                            "type", type,
                            "reason", p.getReason() != null ? p.getReason() : "N/A",
                            "staff", p.getOperator(),
                            "date", plugin.getConfigUtil().messages.formatDate(p.getDate()));
                    sender.sendMessage(entry);
                }
                sender.sendMessage(plugin.getConfigUtil().messages.get("history-footer",
                        "page", String.valueOf(page), "total", String.valueOf(Math.max(1, totalPages))));
            });
        });
        return true;
    }

    private int parseInt(String s, int def) {
        try { return Math.max(1, Integer.parseInt(s)); } catch (NumberFormatException e) { return def; }
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }
}
