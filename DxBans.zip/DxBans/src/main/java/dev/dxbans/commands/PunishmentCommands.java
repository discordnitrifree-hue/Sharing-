package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// TEMPBAN COMMAND
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class TempBanCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    TempBanCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.tempban")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 2) { sender.sendMessage(ColorUtil.color("&cUsage: /tempban <player> <duration> [reason]")); return true; }

        String targetName = args[0];
        String durationStr = args[1];
        long duration = DurationUtil.parse(durationStr);
        if (duration == -1) { plugin.getConfigUtil().messages.send(sender, "invalid-duration"); return true; }

        boolean silent = args.length > 2 && args[2].equals("-s");
        int reasonStart = silent ? 3 : 2;
        String reason = args.length > reasonStart ?
                String.join(" ", Arrays.copyOfRange(args, reasonStart, args.length)) :
                plugin.getConfigUtil().getDefaultReason("tempban");
        reason = plugin.getConfigUtil().resolveReason(reason);

        Player online = Bukkit.getPlayerExact(targetName);
        UUID targetUUID; String finalName;
        if (online != null) { targetUUID = online.getUniqueId(); finalName = online.getName(); }
        else {
            @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(targetName);
            if (!off.hasPlayedBefore()) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", targetName); return true; }
            targetUUID = off.getUniqueId(); finalName = off.getName() != null ? off.getName() : targetName;
        }

        if (plugin.getBanManager().isBanned(targetUUID)) { plugin.getConfigUtil().messages.send(sender, "ban-already", "player", finalName); return true; }

        String op = sender instanceof Player ? sender.getName() : "Console";
        UUID opUUID = sender instanceof Player ? ((Player)sender).getUniqueId() : null;
        final String fr = reason; final boolean fs = silent; final long fd = duration;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Punishment p = plugin.getBanManager().tempban(targetUUID, finalName, fr, op, opUUID, plugin.getConfigUtil().getServerName(), fd, fs);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (online != null && online.isOnline()) online.kickPlayer(ColorUtil.color("&cYou are temp-banned for &e" + DurationUtil.format(fd) + "&c.\n&7Reason: &f" + fr));
                plugin.getConfigUtil().messages.send(sender, "tempban-success", "player", finalName, "staff", op, "duration", DurationUtil.format(fd));
                if (!fs && plugin.getConfigUtil().shouldBroadcast("tempban")) {
                    String msg = ColorUtil.color(plugin.getConfigUtil().getBroadcastFormat("tempban")
                            .replace("{player}", finalName).replace("{staff}", op).replace("{duration}", DurationUtil.format(fd)).replace("{reason}", fr));
                    if (!msg.isEmpty()) { Bukkit.getOnlinePlayers().forEach(pl -> pl.sendMessage(msg)); Bukkit.getConsoleSender().sendMessage(msg); }
                }
            });
        });
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        if (args.length == 2) return Arrays.asList("1h","6h","12h","1d","3d","7d","14d","30d");
        return Collections.emptyList();
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// UNBAN COMMAND
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class UnbanCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    UnbanCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.unban")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /unban <player>")); return true; }
        String name = args[0];
        @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(name);
        if (off.getUniqueId() == null) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", name); return true; }
        String op = sender instanceof Player ? sender.getName() : "Console";
        boolean result = plugin.getBanManager().unban(off.getUniqueId(), op);
        if (result) plugin.getConfigUtil().messages.send(sender, "unban-success", "player", name, "staff", op);
        else plugin.getConfigUtil().messages.send(sender, "unban-not-banned", "player", name);
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) { return Collections.emptyList(); }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MUTE COMMAND
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class MuteCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    MuteCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.mute")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /mute <player> [reason]")); return true; }
        String targetName = args[0];
        boolean silent = args.length > 1 && args[1].equals("-s");
        int rs = silent ? 2 : 1;
        String reason = args.length > rs ? String.join(" ", Arrays.copyOfRange(args, rs, args.length)) : plugin.getConfigUtil().getDefaultReason("mute");
        reason = plugin.getConfigUtil().resolveReason(reason);
        Player online = Bukkit.getPlayerExact(targetName);
        UUID uuid; String name;
        if (online != null) { uuid = online.getUniqueId(); name = online.getName(); }
        else {
            @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(targetName);
            if (!off.hasPlayedBefore()) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", targetName); return true; }
            uuid = off.getUniqueId(); name = off.getName() != null ? off.getName() : targetName;
        }
        if (plugin.getMuteManager().isMuted(uuid)) { plugin.getConfigUtil().messages.send(sender, "mute-already", "player", name); return true; }
        String op = sender instanceof Player ? sender.getName() : "Console";
        UUID opUUID = sender instanceof Player ? ((Player)sender).getUniqueId() : null;
        final String fr = reason; final boolean fs = silent; final UUID fuu = uuid; final String fn = name;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getMuteManager().mute(fuu, fn, fr, op, opUUID, plugin.getConfigUtil().getServerName(), fs);
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getConfigUtil().messages.send(sender, "mute-success", "player", fn, "staff", op);
                if (online != null && online.isOnline()) online.sendMessage(ColorUtil.color("&cYou have been muted. Reason: &f" + fr));
                if (!fs && plugin.getConfigUtil().shouldBroadcast("mute")) {
                    String msg = ColorUtil.color(plugin.getConfigUtil().getBroadcastFormat("mute").replace("{player}", fn).replace("{staff}", op).replace("{reason}", fr));
                    if (!msg.isEmpty()) { Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(msg)); }
                }
            });
        });
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// TEMPMUTE COMMAND
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class TempMuteCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    TempMuteCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.tempmute")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 2) { sender.sendMessage(ColorUtil.color("&cUsage: /tempmute <player> <duration> [reason]")); return true; }
        long duration = DurationUtil.parse(args[1]);
        if (duration == -1) { plugin.getConfigUtil().messages.send(sender, "invalid-duration"); return true; }
        String targetName = args[0];
        String reason = args.length > 2 ? String.join(" ", Arrays.copyOfRange(args, 2, args.length)) : plugin.getConfigUtil().getDefaultReason("tempmute");
        reason = plugin.getConfigUtil().resolveReason(reason);
        Player online = Bukkit.getPlayerExact(targetName);
        UUID uuid; String name;
        if (online != null) { uuid = online.getUniqueId(); name = online.getName(); }
        else {
            @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(targetName);
            if (!off.hasPlayedBefore()) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", targetName); return true; }
            uuid = off.getUniqueId(); name = off.getName() != null ? off.getName() : targetName;
        }
        String op = sender instanceof Player ? sender.getName() : "Console";
        UUID opUUID = sender instanceof Player ? ((Player)sender).getUniqueId() : null;
        final String fr = reason; final long fd = duration; final UUID fuu = uuid; final String fn = name;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getMuteManager().tempmute(fuu, fn, fr, op, opUUID, plugin.getConfigUtil().getServerName(), fd, false);
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getConfigUtil().messages.send(sender, "tempmute-success", "player", fn, "staff", op, "duration", DurationUtil.format(fd));
                if (online != null && online.isOnline()) online.sendMessage(ColorUtil.color("&cYou have been muted for &e" + DurationUtil.format(fd) + "&c. Reason: &f" + fr));
            });
        });
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        if (args.length == 2) return Arrays.asList("30m","1h","6h","12h","1d","7d");
        return Collections.emptyList();
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// UNMUTE COMMAND
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class UnmuteCommand implements CommandExecutor {
    private final DxBans plugin;
    UnmuteCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.unmute")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /unmute <player>")); return true; }
        @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(args[0]);
        if (off.getUniqueId() == null) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", args[0]); return true; }
        String op = sender instanceof Player ? sender.getName() : "Console";
        boolean r = plugin.getMuteManager().unmute(off.getUniqueId(), op);
        if (r) { plugin.getConfigUtil().messages.send(sender, "unmute-success", "player", args[0], "staff", op); Player p = Bukkit.getPlayerExact(args[0]); if (p != null) p.sendMessage(ColorUtil.color("&aYou have been unmuted.")); }
        else plugin.getConfigUtil().messages.send(sender, "unmute-not-muted", "player", args[0]);
        return true;
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// KICK COMMAND
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class KickCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    KickCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.kick")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /kick <player> [reason]")); return true; }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", args[0]); return true; }
        String reason = args.length > 1 ? String.join(" ", Arrays.copyOfRange(args, 1, args.length)) : plugin.getConfigUtil().getDefaultReason("kick");
        reason = plugin.getConfigUtil().resolveReason(reason);
        String op = sender instanceof Player ? sender.getName() : "Console";
        List<String> kickLines = plugin.getConfig().getStringList("punishments.kick.kick-message");
        StringBuilder kb = new StringBuilder();
        for (String line : kickLines) kb.append(ColorUtil.color(line.replace("{reason}", reason).replace("{staff}", op).replace("{server}", plugin.getConfigUtil().getServerName()))).append("\n");
        target.kickPlayer(kb.toString().trim());
        plugin.getConfigUtil().messages.send(sender, "kick-success", "player", target.getName(), "staff", op);
        if (plugin.getConfigUtil().shouldBroadcast("kick")) {
            String msg = ColorUtil.color(plugin.getConfigUtil().getBroadcastFormat("kick").replace("{player}", target.getName()).replace("{staff}", op).replace("{reason}", reason));
            if (!msg.isEmpty()) Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(msg));
        }
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MASSKICK COMMAND
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class MassKickCommand implements CommandExecutor {
    private final DxBans plugin;
    MassKickCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.masskick")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        String reason = args.length > 0 ? String.join(" ", args) : "Server maintenance";
        String finalReason = reason;
        Bukkit.getOnlinePlayers().forEach(p -> { if (!p.hasPermission("dxbans.masskick")) p.kickPlayer(ColorUtil.color("&cYou have been kicked.\n&7Reason: &f" + finalReason)); });
        plugin.getConfigUtil().messages.send(sender, "masskick-success");
        return true;
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PUBLIC WRAPPERS (package-private classes above need public access)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
