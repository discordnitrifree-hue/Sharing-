package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class UnwarnCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    public UnwarnCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.unwarn")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /unwarn <player> [id]")); return true; }

        @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(args[0]);
        if (!off.hasPlayedBefore() && off.getName() == null) {
            plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", args[0]);
            return true;
        }

        String op = sender instanceof Player ? sender.getName() : "Console";
        final UUID uuid = off.getUniqueId();
        final String name = off.getName() != null ? off.getName() : args[0];

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            boolean result;
            if (args.length > 1) {
                // Remove by ID
                try {
                    long id = Long.parseLong(args[1]);
                    result = plugin.getWarnManager().removeWarn(id, op);
                } catch (NumberFormatException e) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            sender.sendMessage(ColorUtil.color("&cInvalid warning ID.")));
                    return;
                }
            } else {
                // Remove latest warning
                result = plugin.getWarnManager().removeLatestWarn(uuid, op);
            }

            final boolean fr = result;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (fr) plugin.getConfigUtil().messages.send(sender, "unwarn-success", "player", name);
                else sender.sendMessage(ColorUtil.color("&cNo active warnings found for &f" + name + "&c."));
            });
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream()
                .map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase()))
                .collect(Collectors.toList());
        return Collections.emptyList();
    }
}
