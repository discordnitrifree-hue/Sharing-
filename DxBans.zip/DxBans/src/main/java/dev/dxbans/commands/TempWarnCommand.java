package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class TempWarnCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    public TempWarnCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.tempwarn")) {
            plugin.getConfigUtil().messages.send(sender, "no-permission");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.color("&cUsage: /tempwarn <player> <duration> [reason]"));
            return true;
        }

        long duration = DurationUtil.parse(args[1]);
        if (duration == -1) {
            plugin.getConfigUtil().messages.send(sender, "invalid-duration");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.getConfigUtil().messages.send(sender, "player-online-only");
            return true;
        }

        String reason = args.length > 2
                ? String.join(" ", Arrays.copyOfRange(args, 2, args.length))
                : plugin.getConfigUtil().getDefaultReason("warn");
        reason = plugin.getConfigUtil().resolveReason(reason);

        String op = sender instanceof Player ? sender.getName() : "Console";
        UUID opUUID = sender instanceof Player ? ((Player) sender).getUniqueId() : null;
        final String finalReason = reason;
        final long finalDuration = duration;
        final Player finalTarget = target;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getWarnManager().tempwarn(
                    finalTarget.getUniqueId(), finalTarget.getName(),
                    finalReason, op, opUUID,
                    plugin.getConfigUtil().getServerName(), finalDuration
            );
            int count = plugin.getWarnManager().getActiveWarnCount(finalTarget.getUniqueId());

            Bukkit.getScheduler().runTask(plugin, () -> {
                sender.sendMessage(ColorUtil.color("&aWarned &f" + finalTarget.getName()
                        + " &afor &e" + DurationUtil.format(finalDuration) + "&a. Reason: &f" + finalReason));
                finalTarget.sendMessage(ColorUtil.color(
                        "&eYou have been temporarily warned for &b" + DurationUtil.format(finalDuration)
                        + "&e by &f" + op + "&e. Reason: &f" + finalReason
                        + " &8(&e" + count + " warnings total&8)"));
            });
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream()
                .map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase()))
                .collect(Collectors.toList());
        if (args.length == 2) return Arrays.asList("30m", "1h", "6h", "12h", "1d");
        return Collections.emptyList();
    }
}
