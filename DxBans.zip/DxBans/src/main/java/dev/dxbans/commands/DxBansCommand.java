package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.utils.ColorUtil;
import org.bukkit.command.*;

import java.util.*;

public class DxBansCommand implements CommandExecutor {
    private final DxBans plugin;
    public DxBansCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("dxbans.admin")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }

        if (args.length == 0) {
            showHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.getConfigUtil().reload();
                plugin.getConfigUtil().messages.send(sender, "reload-success");
            }
            case "info" -> {
                sender.sendMessage(ColorUtil.color("&8&m──────────────────────────────────────"));
                sender.sendMessage(ColorUtil.color("&b&lDxBans &8v&7" + plugin.getDescription().getVersion()));
                sender.sendMessage(ColorUtil.color("&7License: &f" + plugin.getLicenseManager().getMaskedKey()));
                sender.sendMessage(ColorUtil.color("&7Status: " + (plugin.isLicenseValid() ? "&aActive" : "&cInactive")));
                sender.sendMessage(ColorUtil.color("&7MC Version: &f" + org.bukkit.Bukkit.getBukkitVersion()));
                sender.sendMessage(ColorUtil.color("&7DB Type: &f" + plugin.getConfig().getString("database.type", "sqlite").toUpperCase()));
                sender.sendMessage(ColorUtil.color("&8&m──────────────────────────────────────"));
            }
            case "stats" -> {
                org.bukkit.Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                    int bans   = plugin.getBanManager().getTotalBans();
                    int mutes  = plugin.getMuteManager().getTotalMutes();
                    int warns  = plugin.getWarnManager().getTotalWarns();
                    org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
                        sender.sendMessage(ColorUtil.color("&8&m──────────────────────────────────────"));
                        sender.sendMessage(ColorUtil.color("&b&lDxBans Statistics"));
                        sender.sendMessage(ColorUtil.color("&7Total Bans: &e" + bans));
                        sender.sendMessage(ColorUtil.color("&7Total Mutes: &e" + mutes));
                        sender.sendMessage(ColorUtil.color("&7Total Warns: &e" + warns));
                        sender.sendMessage(ColorUtil.color("&8&m──────────────────────────────────────"));
                    });
                });
            }
            case "debug" -> {
                sender.sendMessage(ColorUtil.color("&eLicense valid: &f" + plugin.isLicenseValid()));
                sender.sendMessage(ColorUtil.color("&eDB connected: &f" + (plugin.getDatabaseManager() != null)));
                sender.sendMessage(ColorUtil.color("&eBanned cache: &f" + (plugin.getBanManager() != null)));
            }
            case "license" -> {
                sender.sendMessage(ColorUtil.color("&eLicense key: &f" + plugin.getLicenseManager().getMaskedKey()));
                sender.sendMessage(ColorUtil.color("&eStatus: " + (plugin.isLicenseValid() ? "&aVALID" : "&cINVALID")));
            }
            default -> showHelp(sender);
        }
        return true;
    }

    private void showHelp(CommandSender sender) {
        sender.sendMessage(ColorUtil.color("&8&m──────────────────────────────────────"));
        sender.sendMessage(ColorUtil.color("&b&lDxBans Admin Commands"));
        sender.sendMessage(ColorUtil.color("&e/dxbans reload &7- Reload configuration"));
        sender.sendMessage(ColorUtil.color("&e/dxbans info &7- Plugin information"));
        sender.sendMessage(ColorUtil.color("&e/dxbans stats &7- Punishment statistics"));
        sender.sendMessage(ColorUtil.color("&e/dxbans debug &7- Debug information"));
        sender.sendMessage(ColorUtil.color("&e/dxbans license &7- View license info"));
        sender.sendMessage(ColorUtil.color("&8&m──────────────────────────────────────"));
    }
}
