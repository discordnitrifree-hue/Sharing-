package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class FreezeCommand implements CommandExecutor, TabCompleter {
    private final DxBans plugin;
    public FreezeCommand(DxBans plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) return true;
        if (!sender.hasPermission("dxbans.freeze")) { plugin.getConfigUtil().messages.send(sender, "no-permission"); return true; }
        if (args.length < 1) { sender.sendMessage(ColorUtil.color("&cUsage: /freeze <player>")); return true; }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) { plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", args[0]); return true; }
        String op = sender instanceof Player ? sender.getName() : "Console";
        if (plugin.getFreezeManager().isFrozen(target.getUniqueId())) {
            plugin.getFreezeManager().unfreeze(target.getUniqueId());
            plugin.getConfigUtil().messages.send(sender, "unfreeze-success", "player", target.getName());
            target.sendMessage(ColorUtil.color(plugin.getConfig().getString("freeze.unfreeze-message", "&aYou have been unfrozen.")));
        } else {
            plugin.getFreezeManager().freeze(target.getUniqueId());
            plugin.getConfigUtil().messages.send(sender, "freeze-success", "player", target.getName(), "staff", op);
            target.sendMessage(ColorUtil.color(plugin.getConfig().getString("freeze.freeze-message", "&bYou have been frozen by a staff member. Please wait.")));
            if (plugin.getConfig().getBoolean("freeze.staff-notify", true)) {
                String perm = plugin.getConfig().getString("freeze.staff-notify-permission", "dxbans.freeze.notify");
                String msg = ColorUtil.color("&e" + op + " &7froze &e" + target.getName() + "&7.");
                Bukkit.getOnlinePlayers().forEach(p -> { if (p.hasPermission(perm) && !p.equals(sender)) p.sendMessage(msg); });
            }
        }
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }
}
