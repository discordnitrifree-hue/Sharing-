package dev.dxbans.commands;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class BanCommand implements CommandExecutor, TabCompleter {

    private final DxBans plugin;

    public BanCommand(DxBans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.isLicenseValid()) {
            sender.sendMessage(ColorUtil.color(plugin.getConfigUtil().messages.get("plugin-disabled")));
            return true;
        }

        if (!sender.hasPermission("dxbans.ban")) {
            plugin.getConfigUtil().messages.send(sender, "no-permission");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(ColorUtil.color("&cUsage: /ban <player> [-s] [reason]"));
            return true;
        }

        String targetName = args[0];
        boolean silent = false;
        int reasonStart = 1;

        // Check for -s flag (silent)
        if (args.length > 1 && args[1].equals("-s")) {
            silent = true;
            reasonStart = 2;
        }

        // Build reason
        String reason = args.length > reasonStart ?
                String.join(" ", Arrays.copyOfRange(args, reasonStart, args.length)) :
                plugin.getConfigUtil().getDefaultReason("ban");

        // Resolve reason shortcuts (#hack → "Hacking / Using Cheats")
        reason = plugin.getConfigUtil().resolveReason(reason);

        // Find player (online or offline)
        Player online = Bukkit.getPlayerExact(targetName);
        OfflinePlayer target;
        UUID targetUUID;
        String finalName;

        if (online != null) {
            target = online;
            targetUUID = online.getUniqueId();
            finalName = online.getName();
        } else {
            // Try offline
            @SuppressWarnings("deprecation")
            OfflinePlayer offline = Bukkit.getOfflinePlayer(targetName);
            if (!offline.hasPlayedBefore() && offline.getName() == null) {
                plugin.getConfigUtil().messages.send(sender, "player-not-found", "player", targetName);
                return true;
            }
            targetUUID = offline.getUniqueId();
            finalName = offline.getName() != null ? offline.getName() : targetName;
        }

        // Check exempt
        if (online != null && online.hasPermission("dxbans.exempt")) {
            plugin.getConfigUtil().messages.send(sender, "ban-exempt", "player", finalName);
            return true;
        }

        // Already banned?
        if (plugin.getBanManager().isBanned(targetUUID)) {
            plugin.getConfigUtil().messages.send(sender, "ban-already", "player", finalName);
            return true;
        }

        String operatorName = sender instanceof Player ? sender.getName() : "Console";
        UUID operatorUUID = sender instanceof Player ? ((Player) sender).getUniqueId() : null;
        String server = plugin.getConfigUtil().getServerName();
        final String finalReason = reason;
        final boolean finalSilent = silent;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Punishment punishment = plugin.getBanManager().ban(
                    targetUUID, finalName, finalReason, operatorName, operatorUUID, server, finalSilent
            );

            Bukkit.getScheduler().runTask(plugin, () -> {
                // Kick if online
                if (online != null && online.isOnline()) {
                    List<String> kickLines = plugin.getConfig().getStringList("punishments.ban.ban-message");
                    StringBuilder kickMsg = new StringBuilder();
                    for (String line : kickLines) {
                        kickMsg.append(ColorUtil.color(applyVars(line, punishment))).append("\n");
                    }
                    online.kickPlayer(kickMsg.toString().trim());
                }

                // Success message
                plugin.getConfigUtil().messages.send(sender, "ban-success", "player", finalName, "staff", operatorName);

                // Broadcast
                if (!finalSilent && plugin.getConfigUtil().shouldBroadcast("ban")) {
                    String broadcastMsg = plugin.getConfigUtil().getBroadcastFormat("ban");
                    if (!broadcastMsg.isEmpty()) {
                        broadcastMsg = applyVars(broadcastMsg, punishment);
                        String finalBroadcast = ColorUtil.color(broadcastMsg);
                        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(finalBroadcast));
                        Bukkit.getConsoleSender().sendMessage(finalBroadcast);
                    }
                }
            });
        });

        return true;
    }

    private String applyVars(String text, Punishment p) {
        return text
                .replace("{player}", p.getPlayerName())
                .replace("{reason}", p.getReason())
                .replace("{staff}", p.getOperator())
                .replace("{server}", plugin.getConfigUtil().getServerName())
                .replace("{date}", plugin.getConfigUtil().messages.formatDate(p.getDate()))
                .replace("{duration}", "Permanent")
                .replace("{id}", String.valueOf(p.getId()));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2) {
            return plugin.getConfig().getConfigurationSection("reason-shortcuts")
                    .getKeys(false).stream()
                    .map(k -> "#" + k)
                    .filter(k -> k.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
