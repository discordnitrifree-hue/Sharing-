package dev.dxbans.listeners;

import dev.dxbans.DxBans;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class PlayerMoveListener implements Listener {

    private final DxBans plugin;

    public PlayerMoveListener(DxBans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!plugin.isLicenseValid()) return;
        if (!plugin.getConfig().getBoolean("freeze.block-movement", true)) return;

        if (plugin.getFreezeManager().isFrozen(event.getPlayer().getUniqueId())) {
            // Allow head rotation but block actual movement
            if (event.getFrom().getBlockX() != event.getTo().getBlockX() ||
                event.getFrom().getBlockY() != event.getTo().getBlockY() ||
                event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
                event.setTo(event.getFrom().setDirection(event.getTo().getDirection()));
            }
        }
    }
}
