package dev.dxbans.listeners;

import dev.dxbans.DxBans;
import dev.dxbans.utils.ColorUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.List;
import java.util.UUID;

public class CommandListener implements Listener {

    private final DxBans plugin;

    public CommandListener(DxBans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.isLicenseValid()) return;

        UUID uuid = event.getPlayer().getUniqueId();

        // Mute: block certain commands
        if (plugin.getMuteManager().isMuted(uuid)) {
            String cmd = event.getMessage().split(" ")[0].toLowerCase().replace("/", "");
            List<String> blocked = plugin.getConfig().getStringList("punishments.mute.blocked-commands");
            for (String b : blocked) {
                if (b.toLowerCase().replace("/", "").equals(cmd)) {
                    event.setCancelled(true);
                    event.getPlayer().sendMessage(ColorUtil.color("&cYou are muted and cannot use that command."));
                    return;
                }
            }
        }

        // Freeze: block all commands (except allowed ones)
        if (plugin.getFreezeManager().isFrozen(uuid)) {
            if (plugin.getConfig().getBoolean("freeze.block-commands", true)) {
                List<String> allowed = plugin.getConfig().getStringList("freeze.allowed-commands");
                String cmd = "/" + event.getMessage().split(" ")[0].toLowerCase().replace("/", "");
                if (allowed.stream().noneMatch(a -> a.equalsIgnoreCase(cmd))) {
                    event.setCancelled(true);
                    event.getPlayer().sendMessage(ColorUtil.color("&cYou are frozen and cannot use commands."));
                }
            }
        }
    }
}
