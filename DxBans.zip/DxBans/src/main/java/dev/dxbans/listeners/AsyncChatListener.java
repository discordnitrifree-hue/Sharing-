package dev.dxbans.listeners;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.UUID;

@SuppressWarnings("UnstableApiUsage")
public class AsyncChatListener implements Listener {

    private final DxBans plugin;

    public AsyncChatListener(DxBans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!plugin.isLicenseValid()) return;

        UUID uuid = event.getPlayer().getUniqueId();

        if (plugin.getMuteManager().isMuted(uuid)) {
            event.setCancelled(true);
            Punishment mute = plugin.getMuteManager().getActiveMute(uuid);
            if (mute != null) {
                String msg;
                if (mute.isPermanent()) {
                    msg = plugin.getConfigUtil().messages.get("mute-message" ,
                            "reason", mute.getReason(), "remaining", "Permanent");
                } else {
                    msg = plugin.getConfigUtil().messages.get("tempmute-message",
                            "reason", mute.getReason(),
                            "remaining", DurationUtil.formatRemaining(mute.getUntil()));
                }
                event.getPlayer().sendMessage(ColorUtil.color(msg));
            }
            return;
        }

        // ShadowBan: allow chat but make it visible only to staff
        if (plugin.getShadowBanManager().isShadowBanned(uuid)) {
            if (plugin.getConfig().getBoolean("shadowban.chat-visible-to-staff", true)) {
                event.setCancelled(true);
                String staffPerm = plugin.getConfig().getString("shadowban.staff-see-permission", "dxbans.shadowban.see");
                String chatMsg = ColorUtil.color("&7[ShadowBanned] &f<" + event.getPlayer().getName() + "> ");
                // Get the raw message
                net.kyori.adventure.text.TextComponent textComponent = (net.kyori.adventure.text.TextComponent) event.message();
                String rawMessage = textComponent.content();

                plugin.getServer().getOnlinePlayers().forEach(p -> {
                    if (p.hasPermission(staffPerm)) {
                        p.sendMessage(chatMsg + rawMessage);
                    }
                });
                // Also send to the shadowbanned player themselves
                event.getPlayer().sendMessage(chatMsg + rawMessage);
            }
        }
    }
}
