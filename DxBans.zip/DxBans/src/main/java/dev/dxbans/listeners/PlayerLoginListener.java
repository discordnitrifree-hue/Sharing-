package dev.dxbans.listeners;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.utils.ColorUtil;
import dev.dxbans.utils.DurationUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

import java.net.InetAddress;
import java.util.List;
import java.util.UUID;

public class PlayerLoginListener implements Listener {

    private final DxBans plugin;

    public PlayerLoginListener(DxBans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onLogin(PlayerLoginEvent event) {
        if (!plugin.isLicenseValid()) return;

        UUID uuid = event.getPlayer().getUniqueId();
        String name = event.getPlayer().getName();
        InetAddress address = event.getAddress();
        String ip = address != null ? address.getHostAddress() : "unknown";

        // ── UUID BAN CHECK ────────────────────────────────────
        if (plugin.getBanManager().isBanned(uuid)) {
            Punishment p = plugin.getBanManager().getActiveBan(uuid);
            if (p != null) {
                event.disallow(PlayerLoginEvent.Result.KICK_BANNED, buildKickMessage(p, "ban"));
                return;
            }
        }

        // ── IP BAN CHECK ──────────────────────────────────────
        if (plugin.getBanManager().isIpBanned(ip)) {
            Punishment p = plugin.getBanManager().getActiveIpBan(ip);
            if (p != null) {
                event.disallow(PlayerLoginEvent.Result.KICK_BANNED, buildKickMessage(p, "banip"));
                return;
            }
        }

        // ── BLACKLIST CHECK ───────────────────────────────────
        // (Blacklisted players always use the blacklist message)

        // ── GEO-BLOCK ─────────────────────────────────────────
        if (plugin.getConfig().getBoolean("geoip.enabled", true) &&
                plugin.getConfig().getBoolean("geoip.country-block.enabled", false)) {
            if (plugin.getGeoIPManager().isCountryBlocked(ip)) {
                String msg = ColorUtil.color(plugin.getConfig().getString(
                        "geoip.country-block.block-message", "&cYour country is not allowed on this server."));
                event.disallow(PlayerLoginEvent.Result.KICK_OTHER, msg);
                return;
            }
        }

        // ── ALT DETECTION ─────────────────────────────────────
        if (plugin.getConfig().getBoolean("alt-detection.notify-on-join", true)) {
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                List<String> alts = plugin.getAltManager().getAltsByUUID(uuid);
                for (String alt : alts) {
                    if (!alt.equalsIgnoreCase(name)) {
                        UUID altUUID = plugin.getAltManager().getUUIDByName(alt);
                        if (altUUID != null && plugin.getBanManager().isBanned(altUUID)) {
                            // Notify staff
                            String notifyMsg = plugin.getConfigUtil().messages.get("alts-notify",
                                    "player", name, "original", alt);
                            plugin.getServer().getScheduler().runTask(plugin, () ->
                                    plugin.getServer().getOnlinePlayers().forEach(p -> {
                                        if (p.hasPermission("dxbans.alts.notify")) {
                                            p.sendMessage(notifyMsg);
                                        }
                                    })
                            );
                            break;
                        }
                    }
                }
            });
        }
    }

    private String buildKickMessage(Punishment p, String type) {
        List<String> lines = plugin.getConfig().getStringList("punishments." + type + ".ban-message");
        if (lines.isEmpty()) {
            lines = List.of("&cYou are banned. Reason: {reason}");
        }
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(ColorUtil.color(applyVars(line, p))).append("\n");
        }
        return sb.toString().trim();
    }

    private String applyVars(String text, Punishment p) {
        return text
                .replace("{player}", p.getPlayerName())
                .replace("{reason}", p.getReason())
                .replace("{staff}", p.getOperator())
                .replace("{server}", plugin.getConfigUtil().getServerName())
                .replace("{date}", plugin.getConfigUtil().messages.formatDate(p.getDate()))
                .replace("{expires}", p.isPermanent() ? "Never" : plugin.getConfigUtil().messages.formatDate(p.getUntil()))
                .replace("{remaining}", DurationUtil.formatRemaining(p.getUntil()))
                .replace("{id}", String.valueOf(p.getId()));
    }
}
