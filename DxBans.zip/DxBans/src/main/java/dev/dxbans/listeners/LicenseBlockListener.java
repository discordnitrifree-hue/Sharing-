package dev.dxbans.listeners;

import dev.dxbans.DxBans;
import dev.dxbans.utils.ColorUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

public class LicenseBlockListener implements Listener {

    private final DxBans plugin;

    public LicenseBlockListener(DxBans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onLogin(PlayerLoginEvent event) {
        // Notify OPs that the plugin is disabled due to missing license
        if (event.getPlayer().isOp()) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (event.getPlayer().isOnline()) {
                    event.getPlayer().sendMessage(ColorUtil.color(
                            "&4&l[DxBans] &cPlugin is disabled! &7Enter a valid license key in config.yml.\n" +
                            "&7Get your key at: &bhttps://dxbans.dev/license"
                    ));
                }
            }, 40L);
        }
    }
}
