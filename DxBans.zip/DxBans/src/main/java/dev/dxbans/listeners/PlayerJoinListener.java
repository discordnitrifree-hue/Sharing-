package dev.dxbans.listeners;

import dev.dxbans.DxBans;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.UUID;

public class PlayerJoinListener implements Listener {

    private final DxBans plugin;

    public PlayerJoinListener(DxBans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.isLicenseValid()) return;

        UUID uuid = event.getPlayer().getUniqueId();
        String name = event.getPlayer().getName();
        String ip = event.getPlayer().getAddress() != null ?
                event.getPlayer().getAddress().getAddress().getHostAddress() : "unknown";

        // Record login for alt detection
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getAltManager().recordLogin(uuid, name, ip);

            // GeoIP join notify to staff
            if (plugin.getConfig().getBoolean("geoip.enabled", true) &&
                    plugin.getConfig().getBoolean("geoip.show-on-join", true)) {
                String country = plugin.getGeoIPManager().getCountry(ip);
                String notifyMsg = plugin.getConfigUtil().messages.get("geoip-join-notify",
                        "player", name, "country", country, "ip", ip);
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getServer().getOnlinePlayers().forEach(p -> {
                            if (p.hasPermission("dxbans.geoip.notify")) {
                                p.sendMessage(notifyMsg);
                            }
                        })
                );
            }
        });

        // Shadow ban: hide from tab list
        if (plugin.getShadowBanManager().isShadowBanned(uuid)) {
            if (plugin.getConfig().getBoolean("shadowban.hide-from-player-list", true)) {
                plugin.getServer().getOnlinePlayers().forEach(p -> {
                    if (!p.hasPermission("dxbans.shadowban.see")) {
                        p.hidePlayer(plugin, event.getPlayer());
                    }
                });
            }
        }

        // Hide shadowbanned players from this player
        plugin.getServer().getOnlinePlayers().forEach(other -> {
            if (plugin.getShadowBanManager().isShadowBanned(other.getUniqueId())) {
                if (!event.getPlayer().hasPermission("dxbans.shadowban.see")) {
                    event.getPlayer().hidePlayer(plugin, other);
                }
            }
        });
    }
}
