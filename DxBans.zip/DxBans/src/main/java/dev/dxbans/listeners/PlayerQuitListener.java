package dev.dxbans.listeners;

import dev.dxbans.DxBans;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {

    private final DxBans plugin;

    public PlayerQuitListener(DxBans plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (!plugin.isLicenseValid()) return;
        // Remove from freeze on disconnect (optional - based on config could persist)
        plugin.getFreezeManager().removeOnQuit(event.getPlayer().getUniqueId());
    }
}
