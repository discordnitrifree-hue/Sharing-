package dev.dxbans.placeholders;

import dev.dxbans.DxBans;
import dev.dxbans.models.Punishment;
import dev.dxbans.utils.DurationUtil;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

public class DxBansPlaceholders extends PlaceholderExpansion {

    private final DxBans plugin;

    public DxBansPlaceholders(DxBans plugin) {
        this.plugin = plugin;
    }

    @Override public @NotNull String getIdentifier() { return "dxbans"; }
    @Override public @NotNull String getAuthor()     { return "DxBans"; }
    @Override public @NotNull String getVersion()    { return plugin.getDescription().getVersion(); }
    @Override public boolean persist()               { return true; }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";

        switch (params.toLowerCase()) {
            // ── BAN ──────────────────────────────────────────────
            case "banned" -> {
                return String.valueOf(plugin.getBanManager().isBanned(player.getUniqueId()));
            }
            case "ban_reason" -> {
                Punishment p = plugin.getBanManager().getActiveBan(player.getUniqueId());
                return p != null ? p.getReason() : "";
            }
            case "ban_staff" -> {
                Punishment p = plugin.getBanManager().getActiveBan(player.getUniqueId());
                return p != null ? p.getOperator() : "";
            }
            case "ban_expiry" -> {
                Punishment p = plugin.getBanManager().getActiveBan(player.getUniqueId());
                if (p == null) return "";
                return p.isPermanent() ? "Permanent" : plugin.getConfigUtil().messages.formatDate(p.getUntil());
            }
            case "ban_remaining" -> {
                Punishment p = plugin.getBanManager().getActiveBan(player.getUniqueId());
                if (p == null) return "";
                return DurationUtil.formatRemaining(p.getUntil());
            }
            case "ban_date" -> {
                Punishment p = plugin.getBanManager().getActiveBan(player.getUniqueId());
                return p != null ? plugin.getConfigUtil().messages.formatDate(p.getDate()) : "";
            }

            // ── MUTE ─────────────────────────────────────────────
            case "muted" -> {
                return String.valueOf(plugin.getMuteManager().isMuted(player.getUniqueId()));
            }
            case "mute_reason" -> {
                Punishment p = plugin.getMuteManager().getActiveMute(player.getUniqueId());
                return p != null ? p.getReason() : "";
            }
            case "mute_staff" -> {
                Punishment p = plugin.getMuteManager().getActiveMute(player.getUniqueId());
                return p != null ? p.getOperator() : "";
            }
            case "mute_expiry" -> {
                Punishment p = plugin.getMuteManager().getActiveMute(player.getUniqueId());
                if (p == null) return "";
                return p.isPermanent() ? "Permanent" : plugin.getConfigUtil().messages.formatDate(p.getUntil());
            }
            case "mute_remaining" -> {
                Punishment p = plugin.getMuteManager().getActiveMute(player.getUniqueId());
                if (p == null) return "";
                return DurationUtil.formatRemaining(p.getUntil());
            }

            // ── WARN ─────────────────────────────────────────────
            case "warn_count" -> {
                return String.valueOf(plugin.getWarnManager().getActiveWarnCount(player.getUniqueId()));
            }
            case "total_warnings" -> {
                return String.valueOf(plugin.getWarnManager().getWarnings(player.getUniqueId(), false).size());
            }

            // ── FREEZE / SHADOW ───────────────────────────────────
            case "frozen" -> {
                return String.valueOf(plugin.getFreezeManager().isFrozen(player.getUniqueId()));
            }
            case "shadowbanned" -> {
                return String.valueOf(plugin.getShadowBanManager().isShadowBanned(player.getUniqueId()));
            }

            // ── HISTORY ───────────────────────────────────────────
            case "total_punishments" -> {
                return String.valueOf(plugin.getHistoryManager().getHistoryCount(player.getUniqueId()));
            }

            // ── STATUS ────────────────────────────────────────────
            case "status" -> {
                if (plugin.getBanManager().isBanned(player.getUniqueId())) return "Banned";
                if (plugin.getMuteManager().isMuted(player.getUniqueId())) return "Muted";
                if (plugin.getFreezeManager().isFrozen(player.getUniqueId())) return "Frozen";
                return "Clean";
            }
        }
        return null;
    }
}
